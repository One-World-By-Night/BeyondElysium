<?php

namespace BeyondElysium\Models;

use BeyondElysium\Database\Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Static data-access model for saved search queries.
 */
class Saved_Query {

	/**
	 * Look up a single saved query by its primary key.
	 *
	 * @param int $id
	 * @return object|null
	 */
	public static function find( int $id ) {
		$row = Manager::get_row(
			'SELECT * FROM ' . Manager::table( 'queries' ) . ' WHERE id = %d',
			$id
		);
		return self::decode( $row );
	}

	/**
	 * Return a game's saved queries, newest-recent-search first then by name.
	 *
	 * @param int      $game_id
	 * @param int|null $viewer_id
	 * @return array
	 */
	public static function for_game( int $game_id, ?int $viewer_id = null ): array {
		global $wpdb;
		$table = Manager::table( 'queries' );
		$sql   = $viewer_id === null
			? $wpdb->prepare( "SELECT * FROM {$table} WHERE game_id = %d ORDER BY is_recent_search DESC, name ASC", $game_id )
			: $wpdb->prepare(
				"SELECT * FROM {$table} WHERE game_id = %d AND ( is_recent_search = 0 OR created_by = %d ) ORDER BY is_recent_search DESC, name ASC",
				$game_id,
				$viewer_id
			);
		$rows = $wpdb->get_results( $sql ) ?: [];
		return array_map( [ self::class, 'decode' ], $rows );
	}

	/**
	 * Insert a new saved query.
	 *
	 * @param array $data
	 * @return int|false
	 */
	public static function create( array $data ) {
		$insert = [
			'game_id'          => (int) $data['game_id'],
			'name'             => $data['name'],
			'inventory'        => $data['inventory'] ?? 'char',
			'match_all'        => ! empty( $data['match_all'] ) ? 1 : 0,
			'conditions'       => wp_json_encode( $data['conditions'] ?? [] ),
			'sort_key'         => $data['sort_key'] ?? null,
			'sort_direction'   => $data['sort_direction'] ?? 'asc',
			'is_recent_search' => ! empty( $data['is_recent_search'] ) ? 1 : 0,
			'created_by'       => $data['created_by'] ?? get_current_user_id(),
			'created_at'       => current_time( 'mysql' ),
			'updated_at'       => current_time( 'mysql' ),
		];
		return Manager::insert( 'queries', $insert );
	}

	/**
	 * Update a saved query.
	 *
	 * @param int   $id
	 * @param array $data
	 * @return bool
	 */
	public static function update( int $id, array $data ): bool {
		$allowed = [ 'name', 'inventory', 'match_all', 'conditions', 'sort_key', 'sort_direction' ];
		$update  = [];
		foreach ( $allowed as $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$update[ $field ] = $data[ $field ];
			}
		}
		if ( isset( $update['conditions'] ) && is_array( $update['conditions'] ) ) {
			$update['conditions'] = wp_json_encode( $update['conditions'] );
		}
		if ( array_key_exists( 'match_all', $update ) ) {
			$update['match_all'] = $update['match_all'] ? 1 : 0;
		}
		if ( empty( $update ) ) {
			return false;
		}
		$update['updated_at'] = current_time( 'mysql' );
		return Manager::update( 'queries', $update, [ 'id' => $id ] ) !== false;
	}

	/**
	 * Delete a single saved query by its primary key, including a recent-search row if that is what the ID points to.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		return Manager::delete( 'queries', [ 'id' => $id ] ) !== false;
	}

	/**
	 * Upsert this user's "Most Recent Search" row for a game.
	 *
	 * @param int    $game_id
	 * @param int    $wp_user_id
	 * @param string $inventory
	 * @param bool   $match_all
	 * @param array  $conditions
	 * @return int Query ID.
	 */
	public static function save_recent( int $game_id, int $wp_user_id, string $inventory, bool $match_all, array $conditions ): int {
		global $wpdb;
		$table  = Manager::table( 'queries' );
		$oldest = static fn() => (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE game_id = %d AND created_by = %d AND is_recent_search = 1 ORDER BY id ASC LIMIT 1",
			$game_id,
			$wp_user_id
		) );

		$data = [
			'game_id'    => $game_id,
			'name'       => 'Most Recent Search',
			'inventory'  => $inventory,
			'match_all'  => $match_all,
			'conditions' => $conditions,
		];

		$existing = $oldest();
		if ( $existing ) {
			self::update( $existing, $data );
		} else {
			$data['created_by']       = $wp_user_id;
			$data['is_recent_search'] = true;
			self::create( $data );
		}

		$kept = $oldest();
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$table} WHERE game_id = %d AND created_by = %d AND is_recent_search = 1 AND id <> %d",
			$game_id,
			$wp_user_id,
			$kept
		) );
		return $kept;
	}

	/**
	 * Decode a row's conditions JSON field into an array, and cast its match_all and is_recent_search fields to booleans,
	 * in place.
	 *
	 * @param object|null $row
	 * @return object|null
	 */
	private static function decode( $row ) {
		if ( $row && isset( $row->conditions ) && is_string( $row->conditions ) ) {
			$row->conditions = json_decode( $row->conditions, true ) ?? [];
		}
		if ( $row && isset( $row->match_all ) ) {
			$row->match_all = (bool) $row->match_all;
		}
		if ( $row && isset( $row->is_recent_search ) ) {
			$row->is_recent_search = (bool) $row->is_recent_search;
		}
		return $row;
	}
}
