<?php

namespace BeyondElysium\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Maps GV exchange-file trait lists and trait names onto BE schema blocks.
 */
class Trait_Mapper {

	/** @var array<string,array<string,array<string,mixed>>>|null Cached gex-trait-list-map.php contents. */
	private static $list_map = null;

	/**
	 * Loads gex-trait-list-map.php and caches its contents for the lifetime of the request.
	 *
	 * @return array<string,array<string,array<string,mixed>>>
	 */
	private static function list_map(): array {
		if ( self::$list_map === null ) {
			self::$list_map = require __DIR__ . '/gex-trait-list-map.php';
		}
		return self::$list_map;
	}

	/**
	 * Classifies a whole GV list.
	 *
	 * @param string $stack_slug
	 * @param string $gv_list_name Exactly the `LinkedTraitList.Name` value from the file.
	 * @return array{outcome:string,block_slug?:string,object_type?:string,note?:string}
	 */
	public static function classify_list( string $stack_slug, string $gv_list_name ): array {
		$map     = self::list_map();
		$shared  = $map['shared'] ?? [];
		$forStack = $map[ $stack_slug ] ?? [];

		$entry = $forStack[ $gv_list_name ] ?? $shared[ $gv_list_name ] ?? null;

		if ( $entry === null ) {
			return [
				'outcome' => 'preserve_as_note',
				'note'    => "No mapping declared for \"{$gv_list_name}\" on stack \"{$stack_slug}\".",
			];
		}

		if ( isset( $entry['block_slug'] ) ) {
			$entry['block_slug'] = str_replace( '{stack}', $stack_slug, $entry['block_slug'] );
			// Swaps the shared block the map names for the block the stack declares in its place.
			$entry['block_slug'] = Catalog_Reader::current_slug( $stack_slug, $entry['block_slug'] );
		}

		return $entry;
	}

	/**
	 * Resolves one raw trait name against one or more candidate blocks' real catalogs, through a five-step order:
	 *
	 *   1. exact match                              -> 'exact'
	 *   2. case/whitespace-normalized match          -> 'normalized'
	 *   3. fuzzy match within threshold              -> 'fuzzy' (never auto-applied)
	 *   4. no match, block allows custom             -> 'custom'
	 *   5. no match, block does not allow custom     -> 'unresolved'
	 *
	 * A name matching real items in more than one distinct candidate block is flagged 'ambiguous' rather than silently
	 * resolved to the first hit.
	 *
	 * @param string                 $raw_name  The trait name as it appears in the import.
	 * @param array<int,object>      $blocks    One or more decoded `Schema_Block` rows (candidates).
	 * @return array{outcome:string,block_slug?:string,matched_name?:string,suggestions?:string[],candidates?:string[]}
	 */
	public static function resolve_trait( string $raw_name, array $blocks ): array {
		if ( empty( $blocks ) ) {
			return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
		}

		// Strips a "Combo: "/"Combination: " import prefix from the raw name.
		$raw_name = self::strip_combo_decorations( $raw_name );

		// Exact match, across all candidate blocks - collect every block it hits.
		$exact_hits = self::hits_in_blocks( $raw_name, $blocks, static function ( $item_name ) use ( $raw_name ) {
			return $item_name === $raw_name;
		} );
		if ( count( $exact_hits ) > 1 ) {
			return [ 'outcome' => 'ambiguous', 'candidates' => array_column( $exact_hits, 'block_slug' ) ];
		}
		if ( count( $exact_hits ) === 1 ) {
			return [ 'outcome' => 'exact', 'block_slug' => $exact_hits[0]['block_slug'], 'matched_name' => $raw_name ];
		}

		// Normalized match.
		$needle       = Fuzzy_Matcher::normalize( $raw_name );
		$normal_hits  = self::hits_in_blocks( $raw_name, $blocks, static function ( $item_name ) use ( $needle ) {
			return Fuzzy_Matcher::normalize( $item_name ) === $needle;
		} );
		if ( count( $normal_hits ) > 1 ) {
			return [ 'outcome' => 'ambiguous', 'candidates' => array_column( $normal_hits, 'block_slug' ) ];
		}
		if ( count( $normal_hits ) === 1 ) {
			return [
				'outcome'      => 'normalized',
				'block_slug'   => $normal_hits[0]['block_slug'],
				'matched_name' => $normal_hits[0]['item_name'],
			];
		}

		// Alias match: the raw name is a recorded former name for a catalog item.
		$alias_hits = self::hits_in_blocks( $raw_name, $blocks, static function ( $item_name, $item ) use ( $raw_name ) {
			foreach ( (array) ( $item->aliases ?? [] ) as $alias ) {
				if ( $alias === $raw_name ) {
					return true;
				}
			}
			return false;
		} );
		if ( count( $alias_hits ) > 1 ) {
			return [ 'outcome' => 'ambiguous', 'candidates' => array_column( $alias_hits, 'block_slug' ) ];
		}
		if ( count( $alias_hits ) === 1 ) {
			return [ 'outcome' => 'exact', 'block_slug' => $alias_hits[0]['block_slug'], 'matched_name' => $alias_hits[0]['item_name'] ];
		}

		// Fuzzy match, across every candidate block's catalog pooled together.
		$all_names = [];
		foreach ( $blocks as $block ) {
			foreach ( self::items_of( $block ) as $item ) {
				$all_names[] = $item->name;
			}
		}
		$suggestions = Fuzzy_Matcher::suggest( $raw_name, $all_names );
		if ( ! empty( $suggestions ) ) {
			return [ 'outcome' => 'fuzzy', 'suggestions' => $suggestions ];
		}

		// No match anywhere: allowed as custom only when there is exactly one candidate block that allows it.
		if ( count( $blocks ) === 1 && self::allows_custom( $blocks[0] ) ) {
			return [ 'outcome' => 'custom', 'block_slug' => $blocks[0]->slug ];
		}

		return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
	}

	/**
	 * Resolves one raw trait from a `tiered_power`-classified list against a decoded `tiered_power` `Schema_Block`.
	 *
	 * @param string $raw_name
	 * @param string $raw_total
	 * @param object $block Decoded `tiered_power` `Schema_Block` row.
	 * @return array{outcome:string,block_slug?:string,family?:string,level?:int,power_name?:string,tier?:string|null,tradition?:string,suggestions?:string[]}
	 */
	public static function resolve_tiered_power_trait( string $raw_name, string $raw_total, $block ): array {
		$powers   = (array) ( $block->definition->powers ?? [] );
		$raw_name = self::strip_export_decorations( $raw_name );

		$tradition_split = self::split_tradition_prefix( $raw_name, $powers );
		if ( $tradition_split !== null ) {
			[ $tradition, $family_name ] = $tradition_split;
			$result = self::resolve_numbered_power( $family_name, $raw_total, $powers, $block->slug );
			if ( in_array( $result['outcome'], [ 'exact', 'normalized' ], true ) ) {
				$result['tradition'] = self::normalize_blood_magic_tradition( $tradition, $block );
			}
			return $result;
		}

		if ( $block->definition->blood_magic ?? false ) {
			$alt = self::resolve_blood_magic_alternate_prefix( $raw_name, $raw_total, $powers, $block );
			if ( $alt !== null ) {
				return $alt;
			}
		}

		$named = self::parse_named_power( $raw_name, $powers );
		if ( $named !== null ) {
			return self::resolve_named_power( $named[0], $named[1], $powers, $block->slug );
		}

		return self::resolve_numbered_power( $raw_name, $raw_total, $powers, $block->slug );
	}

	/**
	 * Strips a trailing `*` marker that Grapevine's export tool can attach to a bare family name ("Auspex*"), a power
	 * name ("Spirit Manipulation*"), or right after the family and before the colon ("Thaumaturgy*: The Path of Blood").
	 */
	private static function strip_export_decorations( string $raw_name ): string {
		return trim( str_replace( '*', '', $raw_name ) );
	}

	/**
	 * A combo label at the start of a name: "Combo", "Combi", "Combination" and their plurals and common misspellings,
	 * optionally followed by "Power", "Discipline" or "Dis", then any colon, dash or hash.
	 */
	private const COMBO_LABEL = '/^\s*comb(?:o|os|i|is|ination|inations|inatino|iniation|niation)?\b\.?(?:\s+(?:powers?|disciplines?|dis)\b\.?)?\s*[-\x{2013}\x{2014}:#]*\s*/iu';

	/**
	 * The name a combo carries after its label ("Combo: Draw Fire", "Combi. Discipline: Draw Fire" and "Combo Draw Fire"
	 * all name "Draw Fire"): an empty string for a label with nothing after it, or null when the name has no combo label.
	 */
	public static function combo_name( string $raw_name ): ?string {
		if ( ! preg_match( self::COMBO_LABEL, $raw_name, $label ) ) {
			return null;
		}
		return trim( substr( $raw_name, strlen( $label[0] ) ) );
	}

	/**
	 * Strips a leading combo label from a held combo discipline's exported name, and any trailing constituent-disciplines
	 * note in parentheses or brackets (`"Combo: Blood Sight (Aus 3, PoB 1)"` becomes `"Blood Sight"`).
	 */
	private static function strip_combo_decorations( string $raw_name ): string {
		$name = self::combo_name( $raw_name );
		if ( $name === null ) {
			return $raw_name;
		}
		// Strips one trailing "(...)" or "[...]" group at the very end only.
		return trim( (string) preg_replace( '/\s*[\(\[][^\(\)\[\]]*[\)\]]\s*$/', '', $name ) );
	}

	/**
	 * Splits `"{Tradition}: {Family}"` into `[tradition, family]` only when `{Family}` is an EXACT match for a real
	 * top-level family.
	 *
	 * @param string   $raw_name
	 * @param object[] $powers
	 * @return array{0:string,1:string}|null
	 */
	private static function split_tradition_prefix( string $raw_name, array $powers ): ?array {
		if ( ! preg_match( '/^([^:]+):\s*(.+)$/', $raw_name, $m ) ) {
			return null;
		}
		$tradition = trim( $m[1] );
		$family    = trim( $m[2] );

		foreach ( $powers as $power ) {
			if ( ( $power->name ?? null ) === $family ) {
				return [ $tradition, $family ];
			}
		}

		if ( stripos( $family, 'the ' ) === 0 ) {
			$stripped = trim( substr( $family, 4 ) );
			foreach ( $powers as $power ) {
				if ( ( $power->name ?? null ) === $stripped ) {
					return [ $tradition, $stripped ];
				}
			}
		}

		return null;
	}

	/**
	 * Splits `"{Tradition}: {AlternateName}"` for a blood-magic block only, where `{AlternateName}` is that specific
	 * tradition's own name for a canonical path (the per-power `traditions` map).
	 *
	 * @param string   $raw_name Already export-decoration-stripped.
	 * @param string   $raw_total
	 * @param object[] $powers
	 * @param object   $block Decoded tiered_power Schema_Block, blood_magic-flagged.
	 * @return array{outcome:string,block_slug?:string,family?:string,level?:int,power_name?:string,tier?:string|null,tradition?:string,suggestions?:string[]}|null Null when the raw name has no "X: Y" shape at all, or Y matches no tradition's alternate name.
	 */
	private static function resolve_blood_magic_alternate_prefix( string $raw_name, string $raw_total, array $powers, $block ): ?array {
		if ( ! preg_match( '/^([^:]+):\s*(.+)$/', $raw_name, $m ) ) {
			return null;
		}
		$tradition = self::normalize_blood_magic_tradition( trim( $m[1] ), $block );
		$needle    = Fuzzy_Matcher::normalize( trim( $m[2] ) );

		foreach ( $powers as $power ) {
			$alt = ( (array) ( $power->traditions ?? [] ) )[ $tradition ] ?? null;
			if ( $alt !== null && Fuzzy_Matcher::normalize( (string) $alt ) === $needle ) {
				$result = self::resolve_numbered_power( (string) $power->name, $raw_total, $powers, $block->slug );
				if ( in_array( $result['outcome'], [ 'exact', 'normalized' ], true ) ) {
					$result['tradition'] = $tradition;
				}
				return $result;
			}
		}
		return null;
	}

	/**
	 * Resolves a raw tradition label against a blood-magic block's own known tradition list.
	 *
	 * @param string $raw
	 * @param object $block Decoded tiered_power Schema_Block.
	 */
	private static function normalize_blood_magic_tradition( string $raw, $block ): string {
		$known = (array) ( $block->definition->traditions ?? [] );
		if ( ! ( $block->definition->blood_magic ?? false ) || $known === [] ) {
			return $raw;
		}

		foreach ( $known as $tradition ) {
			if ( Fuzzy_Matcher::normalize( $raw ) === Fuzzy_Matcher::normalize( (string) $tradition ) ) {
				return (string) $tradition;
			}
		}

		$suggestions = Fuzzy_Matcher::suggest( $raw, $known );
		return count( $suggestions ) === 1 ? $suggestions[0] : $raw;
	}

	/**
	 * Applies an ST's explicitly chosen resolution for a `fuzzy` match, re-entering the same lookup an exact match would
	 * take but using the chosen name in place of the raw one.
	 *
	 * @param string      $raw_name
	 * @param string      $raw_total
	 * @param string      $chosen_name
	 * @param object|null $block  Set only for a tiered_power resolution.
	 * @param object[]    $blocks Set only for a trait_list resolution.
	 * @return array
	 */
	public static function resolve_chosen( string $raw_name, string $raw_total, string $chosen_name, $block, array $blocks ): array {
		if ( $block !== null ) {
			$powers   = (array) ( $block->definition->powers ?? [] );
			$raw_name = self::strip_export_decorations( $raw_name );

			$tradition_split = self::split_tradition_prefix( $raw_name, $powers );
			if ( $tradition_split !== null ) {
				$result = self::resolve_numbered_power( $chosen_name, $raw_total, $powers, $block->slug );
				if ( in_array( $result['outcome'], [ 'exact', 'normalized' ], true ) ) {
					$result['tradition'] = self::normalize_blood_magic_tradition( $tradition_split[0], $block );
				}
				return $result;
			}

			$named = self::parse_named_power( $raw_name, $powers );
			if ( $named !== null ) {
				return self::resolve_named_power( $named[0], $chosen_name, $powers, $block->slug );
			}
			return self::resolve_numbered_power( $chosen_name, $raw_total, $powers, $block->slug );
		}

		return self::resolve_trait( $chosen_name, $blocks );
	}

	/**
	 * Split `"{Family}: {Power}"` (tier parenthetical optional) into `[family, power_name]`, or null when the raw name
	 * has no `Family:` shape at all.
	 *
	 * @param string   $raw_name
	 * @param object[] $powers Decoded `definition->powers`; empty is allowed (fallback only).
	 * @return array{0:string,1:string}|null
	 */
	private static function parse_named_power( string $raw_name, array $powers = [] ): ?array {
		$best = null;
		foreach ( $powers as $power ) {
			$family = (string) ( $power->name ?? '' );
			if ( $family === '' ) {
				continue;
			}
			$prefix = $family . ':';
			if ( strncasecmp( $raw_name, $prefix, strlen( $prefix ) ) === 0
				&& ( $best === null || strlen( $family ) > strlen( $best ) )
			) {
				$best = $family;
			}
		}

		if ( $best !== null ) {
			$power_name = trim( substr( $raw_name, strlen( $best ) + 1 ) );
			return $power_name === '' ? null : [ $best, $power_name ];
		}

		foreach ( $powers as $power ) {
			if ( ( $power->name ?? null ) === $raw_name ) {
				return null;
			}
		}

		if ( ! preg_match( '/^([^:]+):\s*(.+)$/', $raw_name, $m ) ) {
			return null;
		}
		return [ trim( $m[1] ), trim( $m[2] ) ];
	}

	/**
	 * Resolves a named-pick power (`"{Family}: {Power}"`) against a family's own levels: exact match first.
	 *
	 * @param string   $family_name
	 * @param string   $power_name
	 * @param object[] $powers
	 * @param string   $block_slug
	 * @return array{outcome:string,block_slug?:string,family?:string,power_name?:string,tier?:string|null,suggestions?:string[]}
	 */
	private static function resolve_named_power( string $family_name, string $power_name, array $powers, string $block_slug ): array {
		// An exact family-name match first, then a recorded `aliases` or `split_from` rename within this block.
		$power = Trait_Alias_Resolver::find_power_by_name( $powers, $family_name );
		if ( $power === null ) {
			return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
		}

		$levels = Power_Levels::all( $power );

		// Tries the name exactly as given first, then with a trailing parenthetical tier removed.
		$candidates = [ $power_name ];
		$stripped   = trim( (string) preg_replace( '/\s*\([^()]+\)\s*$/', '', $power_name ) );
		if ( $stripped !== '' && $stripped !== $power_name ) {
			$candidates[] = $stripped;
		}

		foreach ( $candidates as $candidate ) {
			$exact = Trait_Alias_Resolver::find_level_by_name( $levels, $candidate );
			if ( $exact !== null ) {
				return [
					'outcome'    => 'exact',
					'block_slug' => $block_slug,
					'family'     => $power->name,
					'power_name' => $exact->power_name,
					'tier'       => $exact->tier ?? null,
				];
			}
		}

		foreach ( $candidates as $candidate ) {
			$needle = Fuzzy_Matcher::normalize( $candidate );
			foreach ( $levels as $level ) {
				if ( Fuzzy_Matcher::normalize( $level->power_name ?? '' ) === $needle ) {
					return [
						'outcome'    => 'normalized',
						'block_slug' => $block_slug,
						'family'     => $power->name,
						'power_name' => $level->power_name,
						'tier'       => $level->tier ?? null,
					];
				}
			}
		}

		$names       = array_map( static fn( $l ) => $l->power_name ?? '', $levels );
		$suggestions = Fuzzy_Matcher::suggest( (string) end( $candidates ), $names );
		if ( ! empty( $suggestions ) ) {
			return [ 'outcome' => 'fuzzy', 'suggestions' => $suggestions ];
		}

		return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
	}

	/**
	 * Resolves a numbered-rung power (a bare family name plus a numeric level) against a family's own levels: exact match
	 * first.
	 *
	 * @param string   $raw_name
	 * @param string   $raw_total
	 * @param object[] $powers
	 * @param string   $block_slug
	 * @return array{outcome:string,block_slug?:string,family?:string,level?:int,suggestions?:string[]}
	 */
	private static function resolve_numbered_power( string $raw_name, string $raw_total, array $powers, string $block_slug ): array {
		$exact = self::find_by_name( $powers, $raw_name );
		$power = $exact;
		$outcome_if_found = 'exact';

		if ( $power === null ) {
			// An exact family-name match first, then a recorded `aliases` or `split_from` rename within this block.
			$power = Trait_Alias_Resolver::find_power_by_name( $powers, $raw_name );
			if ( $power !== null ) {
				$outcome_if_found = 'exact';
			}
		}

		if ( $power === null ) {
			$needle = Fuzzy_Matcher::normalize( $raw_name );
			foreach ( $powers as $candidate ) {
				if ( Fuzzy_Matcher::normalize( $candidate->name ) === $needle ) {
					$power = $candidate;
					$outcome_if_found = 'normalized';
					break;
				}
			}
		}

		if ( $power === null ) {
			$names       = array_map( static fn( $p ) => $p->name, $powers );
			$suggestions = Fuzzy_Matcher::suggest( $raw_name, $names );
			if ( ! empty( $suggestions ) ) {
				return [ 'outcome' => 'fuzzy', 'suggestions' => $suggestions ];
			}
			return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
		}

		if ( ! is_numeric( $raw_total ) ) {
			return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
		}

		$level_num = (int) $raw_total;
		foreach ( Power_Levels::all( $power ) as $level ) {
			if ( ( $level->level ?? null ) === $level_num ) {
				return [
					'outcome'    => $outcome_if_found,
					'block_slug' => $block_slug,
					'family'     => $power->name,
					'level'      => $level_num,
				];
			}
		}

		// A rank with several powers tied at one tier carries no level, so it is confirmed by tier presence.
		$tier = self::tier_for_rank( $level_num );
		if ( $tier !== null ) {
			foreach ( Power_Levels::all( $power ) as $level ) {
				if ( ( $level->tier ?? null ) === $tier ) {
					return [
						'outcome'    => $outcome_if_found,
						'block_slug' => $block_slug,
						'family'     => $power->name,
						'level'      => $level_num,
					];
				}
			}
		}

		// The family is real but this exact numbered rung is not; not a name problem, so no suggestions to offer.
		return [ 'outcome' => 'unresolved', 'suggestions' => [] ];
	}

	/**
	 * Maps a numbered rank (1=basic, 2=intermediate,...) to its tier name.
	 */
	private static function tier_for_rank( int $rank ): ?string {
		static $numbered = [
			1 => 'basic', 2 => 'intermediate', 3 => 'advanced', 4 => 'elder',
			5 => 'master', 6 => 'ascended', 7 => 'methuselah',
		];
		return $numbered[ $rank ] ?? null;
	}

	/**
	 * Finds the first item in a list whose named property matches exactly, comparing case-sensitively.
	 *
	 * @param object[] $items
	 * @param string   $name
	 * @param string   $prop
	 * @return object|null
	 */
	private static function find_by_name( array $items, string $name, string $prop = 'name' ) {
		foreach ( $items as $item ) {
			if ( ( $item->{$prop} ?? null ) === $name ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * Collects every candidate block that has at least one item satisfying `$predicate`, stopping at the first matching item
	 * per block. Used by resolve_trait() to find exact and normalized matches across multiple candidate blocks at once.
	 *
	 * @param string   $raw_name  Unused directly here; each predicate closure captures it itself.
	 * @param object[] $blocks
	 * @param callable(string,object):bool $predicate Receives the item's own `name` and the item itself, the latter for an alias
	 *                            check against `$item->aliases`.
	 * @return array<int,array{block_slug:string,item_name:string}>
	 */
	private static function hits_in_blocks( string $raw_name, array $blocks, callable $predicate ): array {
		$hits = [];
		foreach ( $blocks as $block ) {
			foreach ( self::items_of( $block ) as $item ) {
				if ( $predicate( $item->name, $item ) ) {
					$hits[] = [ 'block_slug' => $block->slug, 'item_name' => $item->name ];
					break; // one hit per block is enough to count the block as a match
				}
			}
		}
		return $hits;
	}

	/**
	 * Returns a block's catalog items (`definition->items`) as a plain array, or an empty array when the block has no
	 * items defined.
	 *
	 * @param object $block A decoded Schema_Block row.
	 * @return object[]
	 */
	private static function items_of( $block ): array {
		return (array) ( $block->definition->items ?? [] );
	}

	/**
	 * Checks whether a block's definition allows a custom, unrecognized trait entry to be accepted.
	 *
	 * @param object $block
	 * @return bool
	 */
	private static function allows_custom( $block ): bool {
		return ! empty( $block->definition->allow_custom );
	}
}
