<?php

namespace BeyondElysium\Services\Display;

defined( 'ABSPATH' ) || exit;

/**
 * Formats one `character_changes` row as a short human-readable string, e.g. "Celerity 2 -> 4".
 */
class Change_Description {

	/**
	 * Builds the display string for one change, branching on `$change_type` and reading whatever fields that type's
	 * `$change_data` carries.
	 *
	 * @param string               $change_type
	 * @param array<string,mixed>  $change_data
	 */
	public static function describe( string $change_type, array $change_data ): string {
		// Every word is translated.
		switch ( $change_type ) {
			case 'add_trait':
				$trait = (array) ( $change_data['trait'] ?? [] );
				$name  = $trait['name'] ?? __( 'Unknown', 'beyond-elysium' );
				if ( isset( $trait['level'] ) ) {
					/* translators: 1: trait or power name, 2: level */
					return sprintf( __( 'Added %1$s %2$s', 'beyond-elysium' ), $name, $trait['level'] );
				}
				$count  = $trait['count'] ?? 1;
				$suffix = ! empty( $trait['specialization'] ) ? ' (' . $trait['specialization'] . ')' : '';
				return $count > 1
					/* translators: 1: trait name, 2: count, 3: specialization in parentheses, or nothing */
					? sprintf( __( 'Added %1$s x%2$s%3$s', 'beyond-elysium' ), $name, $count, $suffix )
					/* translators: 1: trait name, 2: specialization in parentheses, or nothing */
					: sprintf( __( 'Added %1$s%2$s', 'beyond-elysium' ), $name, $suffix );

			case 'remove_trait':
				$trait = (array) ( $change_data['trait'] ?? [] );
				/* translators: %s: trait name */
				return sprintf( __( 'Removed %s', 'beyond-elysium' ), $trait['name'] ?? __( 'Unknown', 'beyond-elysium' ) );

			case 'modify_trait':
				$trait    = (array) ( $change_data['trait'] ?? [] );
				$previous = isset( $change_data['previous'] ) ? (array) $change_data['previous'] : null;
				$name     = $trait['name'] ?? ( $previous['name'] ?? __( 'Unknown', 'beyond-elysium' ) );

				if ( isset( $trait['level'] ) ) {
					return isset( $previous['level'] )
						/* translators: 1: power name, 2: level before, 3: level after */
						? sprintf( __( '%1$s %2$s → %3$s', 'beyond-elysium' ), $name, $previous['level'], $trait['level'] )
						/* translators: 1: power name, 2: level after */
						: sprintf( __( '%1$s → level %2$s', 'beyond-elysium' ), $name, $trait['level'] );
				}
				if ( isset( $trait['count'] ) ) {
					return isset( $previous['count'] )
						/* translators: 1: trait name, 2: count before, 3: count after */
						? sprintf( __( '%1$s x%2$s → x%3$s', 'beyond-elysium' ), $name, $previous['count'], $trait['count'] )
						/* translators: 1: trait name, 2: count after */
						: sprintf( __( '%1$s → x%2$s', 'beyond-elysium' ), $name, $trait['count'] );
				}
				/* translators: %s: trait name */
				return sprintf( __( '%s updated', 'beyond-elysium' ), $name );

			case 'modify_resource':
				$values = (array) ( $change_data['values'] ?? [] );
				if ( empty( $values ) ) {
					return __( 'Resource updated', 'beyond-elysium' );
				}
				$pool  = array_key_first( $values );
				$value = (array) $values[ $pool ];
				/* translators: 1: resource pool name, 2: permanent value, 3: temporary value */
				return sprintf( __( '%1$s: %2$s perm / %3$s temp', 'beyond-elysium' ), $pool, $value['permanent'] ?? '?', $value['temporary'] ?? '?' );

			case 'modify_identity':
				$fields = (array) ( $change_data['fields'] ?? [] );
				if ( empty( $fields ) ) {
					return __( 'Identity updated', 'beyond-elysium' );
				}
				$field = array_key_first( $fields );
				$value = $fields[ $field ];
				// A multiselect's choices read as the sheet shows them.
				$value = is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
				/* translators: 1: identity field name, 2: its new value */
				return sprintf( __( '%1$s → %2$s', 'beyond-elysium' ), $field, $value );

			case 'xp_earn':
				$amount = $change_data['amount'] ?? 0;
				$reason = ! empty( $change_data['reason'] ) ? ' (' . $change_data['reason'] . ')' : '';
				/* translators: 1: XP awarded, 2: the award's reason in parentheses, or nothing */
				return sprintf( __( '+%1$s XP%2$s', 'beyond-elysium' ), $amount, $reason );

			case 'xp_adjust':
				$amount = $change_data['amount'] ?? 0;
				$reason = ! empty( $change_data['reason'] ) ? ' (' . $change_data['reason'] . ')' : '';
				/* translators: 1: signed XP adjustment, 2: the adjustment's reason in parentheses, or nothing */
				return sprintf( __( 'XP adjusted by %1$s%2$s', 'beyond-elysium' ), $amount, $reason );

			case 'import_note':
				return ! empty( $change_data['reason'] ) ? $change_data['reason'] : __( 'Imported note', 'beyond-elysium' );

			case 'catalog_rekey':
				$counts  = (array) ( $change_data['counts'] ?? [] );
				$moved     = (int) ( $counts['moved_rows'] ?? 0 );
				$matched   = (int) ( $counts['rekeyed'] ?? 0 );
				$respelled = (int) ( $counts['respelled'] ?? 0 );
				$parts     = [];
				if ( $moved > 0 ) {
					/* translators: %d: how many rows the catalog update moved to their new section */
					$parts[] = sprintf( _n( '%d row moved to its new catalog section', '%d rows moved to their new catalog sections', $moved, 'beyond-elysium' ), $moved );
				}
				if ( $matched > 0 ) {
					/* translators: %d: how many custom entries the catalog update matched to a catalog item */
					$parts[] = sprintf( _n( '%d custom entry matched to the catalog', '%d custom entries matched to the catalog', $matched, 'beyond-elysium' ), $matched );
				}
				if ( $respelled > 0 ) {
					/* translators: %d: how many catalog names the catalog update respelled to the spelling the catalog now uses */
					$parts[] = sprintf( _n( '%d name spelled to match the catalog', '%d names spelled to match the catalog', $respelled, 'beyond-elysium' ), $respelled );
				}
				if ( $parts === [] ) {
					return __( 'Catalog update', 'beyond-elysium' );
				}
				/* translators: %s: what the catalog update did, e.g. "24 rows moved to their new catalog sections, 7 custom entries matched to the catalog" */
				return sprintf( __( 'Catalog update: %s', 'beyond-elysium' ), implode( ', ', $parts ) );

			case 'catalog_rekey_revert':
				return ! empty( $change_data['forced'] )
					? __( 'Catalog update undone, including changes made since', 'beyond-elysium' )
					: __( 'Catalog update undone', 'beyond-elysium' );

			case 'propose_world_object':
				/* translators: 1: object type (item/location/rote), 2: its proposed name */
				return sprintf(
					__( 'Proposed %1$s: %2$s', 'beyond-elysium' ),
					$change_data['object_type'] ?? __( 'item', 'beyond-elysium' ),
					$change_data['name'] ?? __( 'Unknown', 'beyond-elysium' )
				);

			case 'propose_faction':
				/* translators: 1: faction type (coterie/pack/cabal/motley/other), 2: its proposed name */
				return sprintf(
					__( 'Proposed %1$s: %2$s', 'beyond-elysium' ),
					$change_data['faction_type'] ?? __( 'group', 'beyond-elysium' ),
					$change_data['name'] ?? __( 'Unknown', 'beyond-elysium' )
				);

			default:
				return __( 'Unknown change', 'beyond-elysium' );
		}
	}

	/**
	 * The signed XP delta one approved change actually applied, matching `Change_Engine::approve()`'s own inline
	 * arithmetic: `xp_earn`/`xp_adjust` carry an already-signed `amount`.
	 *
	 * @param array<string,mixed> $change_data
	 */
	public static function xp_delta( string $change_type, array $change_data, float $xp_cost ): int {
		if ( $change_type === 'xp_earn' || $change_type === 'xp_adjust' ) {
			return (int) ( $change_data['amount'] ?? 0 );
		}
		if ( $xp_cost > 0 ) {
			return -(int) $xp_cost;
		}
		return 0;
	}
}
