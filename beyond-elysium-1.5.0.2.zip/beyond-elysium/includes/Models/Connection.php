<?php

namespace BeyondElysium\Models;

use BeyondElysium\Database\Manager;
use BeyondElysium\Database\Transaction;

defined( 'ABSPATH' ) || exit;

/**
 * Static data-access model for polymorphic entity-to-entity connections.
 */
class Connection {

	/** @var string[] Valid source_type / target_type values. */
	private static $valid_entity_types = [ 'character', 'plot', 'world_object', 'tag', 'faction' ];

	/**
	 * Look up a single connection by its primary key.
	 *
	 * @param int $id
	 * @return object|null
	 */
	public static function find( int $id ) {
		return self::decode( Manager::get_row(
			'SELECT * FROM ' . Manager::table( 'connections' ) . ' WHERE id = %d',
			$id
		) );
	}

	/**
	 * A connection row with its ids as integers (a missing target stays null).
	 *
	 * @param object|null $row
	 * @return object|null
	 */
	private static function decode( ?object $row ): ?object {
		return $row === null ? null : self::cast_ids( $row );
	}

	/**
	 * @param array<int,object>|null $rows
	 * @return array<int,object>
	 */
	private static function decode_all( $rows ): array {
		return array_map( [ self::class, 'cast_ids' ], is_array( $rows ) ? $rows : [] );
	}

	private static function cast_ids( object $row ): object {
		foreach ( [ 'id', 'game_id', 'source_id', 'created_by' ] as $field ) {
			if ( isset( $row->$field ) ) {
				$row->$field = (int) $row->$field;
			}
		}
		if ( isset( $row->target_id ) ) {
			$row->target_id = (int) $row->target_id;
		}
		return $row;
	}

	/**
	 * Return every connection where the given entity is the source side.
	 *
	 * @param string $type
	 * @param int    $id
	 * @return array<int,object>
	 */
	public static function for_source( string $type, int $id ): array {
		return self::decode_all( Manager::get_results(
			'SELECT * FROM ' . Manager::table( 'connections' ) . ' WHERE source_type = %s AND source_id = %d ORDER BY created_at DESC',
			$type,
			$id
		) );
	}

	/**
	 * Return every connection where the given entity is the target side.
	 *
	 * @param string $type
	 * @param int    $id
	 * @return array<int,object>
	 */
	public static function for_target( string $type, int $id ): array {
		return self::decode_all( Manager::get_results(
			'SELECT * FROM ' . Manager::table( 'connections' ) . ' WHERE target_type = %s AND target_id = %d ORDER BY created_at DESC',
			$type,
			$id
		) );
	}

	/**
	 * Return every connection touching an entity, whether it appears as the source or the target.
	 *
	 * @param string $type
	 * @param int    $id
	 * @return array<int,object>
	 */
	public static function for_entity( string $type, int $id ): array {
		global $wpdb;
		$table = Manager::table( 'connections' );
		$sql   = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE (source_type = %s AND source_id = %d) OR (target_type = %s AND target_id = %d) ORDER BY created_at DESC",
			$type,
			$id,
			$type,
			$id
		);
		return self::decode_all( $wpdb->get_results( $sql ) );
	}

	/**
	 * Every connection touching any of several entities of one type, whether as the source or the target.
	 *
	 * @param string $type
	 * @param int[]  $ids
	 * @return array<int,object>
	 */
	public static function for_entities( string $type, array $ids ): array {
		$ids = array_values( array_unique( array_map( 'intval', $ids ) ) );
		if ( empty( $ids ) ) {
			return [];
		}

		global $wpdb;
		$table        = Manager::table( 'connections' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$sql          = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE (source_type = %s AND source_id IN ({$placeholders})) OR (target_type = %s AND target_id IN ({$placeholders}))", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			array_merge( [ $type ], $ids, [ $type ], $ids )
		);
		return self::decode_all( $wpdb->get_results( $sql ) );
	}

	/**
	 * Return every connection belonging to a game.
	 *
	 * @param int                 $game_id
	 * @param array<string,mixed> $args Filters: source_type, target_type.
	 * @return array<int,object>
	 */
	public static function for_game( int $game_id, array $args = [] ): array {
		global $wpdb;
		$table  = Manager::table( 'connections' );
		$where  = [ 'game_id = %d' ];
		$values = [ $game_id ];

		if ( ! empty( $args['source_type'] ) ) {
			$where[]  = 'source_type = %s';
			$values[] = $args['source_type'];
		}
		if ( ! empty( $args['target_type'] ) ) {
			$where[]  = 'target_type = %s';
			$values[] = $args['target_type'];
		}

		$sql = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY created_at DESC';
		$sql = $wpdb->prepare( $sql, $values );
		return self::decode_all( $wpdb->get_results( $sql ) );
	}

	/**
	 * Create a connection between two entities.
	 *
	 * @param array<string,mixed> $data
	 * @return int|false Insert ID (new or existing) on success, false on validation failure.
	 */
	public static function create( array $data ) {
		$source_type = $data['source_type'] ?? '';
		$target_type = $data['target_type'] ?? '';

		if ( ! in_array( $source_type, self::$valid_entity_types, true ) ) {
			return false;
		}
		if ( ! in_array( $target_type, self::$valid_entity_types, true ) ) {
			return false;
		}
		if ( empty( $data['source_id'] ) ) {
			return false;
		}
		// A tag target has no row to point at; every other target type must name one.
		if ( $target_type !== 'tag' && empty( $data['target_id'] ) ) {
			return false;
		}

		$target_id = $target_type === 'tag' ? null : (int) $data['target_id'];
		$label     = $data['label'] ?? null;

		$unit = Transaction::begin( 'be_connection_create' );
		if ( ! self::lock_source( $source_type, (int) $data['source_id'] ) ) {
			Transaction::rollback( $unit );
			return false;
		}

		$existing = self::find_duplicate(
			(int) $data['game_id'],
			$source_type,
			(int) $data['source_id'],
			$target_type,
			$target_id,
			$label
		);
		if ( $existing ) {
			Transaction::commit( $unit );
			return (int) $existing->id;
		}

		$insert = [
			'game_id'     => (int) $data['game_id'],
			'source_type' => $source_type,
			'source_id'   => (int) $data['source_id'],
			'target_type' => $target_type,
			'target_id'   => $target_id,
			'label'       => $label,
			'notes'       => $data['notes'] ?? null,
			'created_by'  => $data['created_by'] ?? get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		];

		$id = Manager::insert( 'connections', $insert );
		if ( ! $id ) {
			Transaction::rollback( $unit );
			return false;
		}

		Transaction::commit( $unit );
		return $id;
	}

	/**
	 * Holds a connection's source row until the surrounding transaction ends.
	 *
	 * @param string $type
	 * @param int    $id
	 * @return bool
	 */
	private static function lock_source( string $type, int $id ): bool {
		global $wpdb;
		$tables = [ 'character' => 'characters', 'plot' => 'plots', 'world_object' => 'world_objects' ];
		if ( ! isset( $tables[ $type ] ) ) {
			return true;
		}

		$wpdb->last_error = '';
		Manager::get_var( 'SELECT id FROM ' . Manager::table( $tables[ $type ] ) . ' WHERE id = %d FOR UPDATE', $id );
		return $wpdb->last_error === '';
	}

	/**
	 * Find an existing connection matching the exact same game, source, target, and label tuple.
	 *
	 * @param int         $game_id
	 * @param string      $source_type
	 * @param int         $source_id
	 * @param string      $target_type
	 * @param int|null    $target_id
	 * @param string|null $label
	 * @return object|null
	 */
	private static function find_duplicate( int $game_id, string $source_type, int $source_id, string $target_type, ?int $target_id, ?string $label ) {
		global $wpdb;
		$table = Manager::table( 'connections' );

		$where  = [ 'game_id = %d', 'source_type = %s', 'source_id = %d', 'target_type = %s' ];
		$values = [ $game_id, $source_type, $source_id, $target_type ];

		if ( $target_id === null ) {
			$where[] = 'target_id IS NULL';
		} else {
			$where[]  = 'target_id = %d';
			$values[] = $target_id;
		}

		if ( $label === null ) {
			$where[] = 'label IS NULL';
		} else {
			$where[]  = 'label = %s';
			$values[] = $label;
		}

		$sql = $wpdb->prepare(
			'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' LIMIT 1',
			$values
		);
		return $wpdb->get_row( $sql );
	}

	/**
	 * Update a connection's label and notes.
	 *
	 * @param int                 $id
	 * @param array<string,mixed> $data
	 * @return bool
	 */
	public static function update( int $id, array $data ): bool {
		$allowed = [ 'label', 'notes' ];
		$update  = [];
		foreach ( $allowed as $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$update[ $field ] = $data[ $field ];
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		$result = Manager::update( 'connections', $update, [ 'id' => $id ] );
		return $result !== false;
	}

	/**
	 * Delete a single connection row by its primary key.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete( int $id ): bool {
		$result = Manager::delete( 'connections', [ 'id' => $id ] );
		return $result !== false;
	}

	/**
	 * Delete every connection referencing a given entity, whether it appears as the source or the target.
	 *
	 * @param string $type
	 * @param int    $id
	 * @return void
	 */
	public static function delete_for_entity( string $type, int $id ): void {
		global $wpdb;
		$table = Manager::table( 'connections' );
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$table} WHERE (source_type = %s AND source_id = %d) OR (target_type = %s AND target_id = %d)",
			$type,
			$id,
			$type,
			$id
		) );
	}

	/**
	 * Return the list of entity type strings a connection's source_type or target_type may hold.
	 *
	 * @return string[]
	 */
	public static function valid_entity_types(): array {
		return self::$valid_entity_types;
	}
}
