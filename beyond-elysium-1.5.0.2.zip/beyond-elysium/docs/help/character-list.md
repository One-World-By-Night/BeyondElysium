# Characters

A searchable, sortable list of characters, with a link to each one's sheet.

## Who can use this

Any member of the chronicle can open this tab. As a player - including a Narrator or the chronicle's Harpy who isn't also an HST or AST - you see only your own characters here. Storytellers (HST and AST) see every character in the chronicle, plus controls to assign or change a character's player and to delete a character. NPCs never appear on this list for anyone - Storytellers manage those from wp-admin's Characters page instead.

## How to get there

My Chronicle → Characters tab.

## The screen

- **+ New Character** (on My Chronicle) - opens the editor with no character, ready to start one.
- **Filters** - **Type** (this chronicle's own creature types, or "All types"), **Status** ("All statuses," or active/inactive/retired/dead/pending), and a search box that matches by name as you type.
- **The table** (stacked into cards on a narrow screen):

  | Column | Shows |
  | --- | --- |
  | (portrait) | A thumbnail, when the character has one |
  | Name | Links to the Sheet tab; carries an "Also active elsewhere" badge while the character has an open visit to another chronicle - "Can't reach a visit" instead if one has gone quiet |
  | Type | Creature type |
  | Status | active, inactive, retired, dead, or pending |
  | XP Earned | Total experience earned |
  | XP Unspent | Experience not yet spent |
  | Player | The assigned player's name. Storyteller-only extras: "(unassigned)" when nobody's linked, and a "now has an account - Confirm" prompt when a pending email match is found |
  | Apply XP | Storyteller-only: a box for an amount and its own **Apply** button |
  | Actions | Storyteller-only: Assign player / Change player, Delete |

  Click a column header to sort by it; click again to reverse the order.
- **Pagination** - Previous / Next, with the current page and the total count.
- **Assign a player** (Storyteller-only modal) - search by at least three letters of a name, or an exact email address (a partial name match never shows an email); assign a result, unassign the current player, or record a pending email for someone who hasn't registered an account yet. A pending email is an invite: the character links itself to them the first time they sign in with that address, and on a chronicle linked to OWbN roles the invite also shows on the [Players](chronicle-players.md) tab.
- **Apply XP** (Storyteller-only) - type a whole number in a row's box and click that row's **Apply**, or type one in several rows - across as many pages as you like - and click **Apply All** below the table once, with one **Reason** shared by every row it sends. A negative number takes XP back; it's refused, with a note under the box, if it would take XP Earned below zero. What you type stays there as you page, sort, filter, or search, until you apply or click **Clear amounts**. Applied XP is granted immediately, the same as a Storyteller's own award anywhere else - it never goes through the Approval Queue.

## Common tasks

### Find your character

1. Open **My Chronicle** → **Characters**.
2. Click its name to open the Sheet.

### Filter or search the list

1. Pick a **Type** or **Status**, or type a name into the search box.

### Sort by a column

1. Click the column header - Name, Type, Status, XP Earned, XP Unspent, or Player.
2. Click it again to reverse the order.

### Assign or change a character's player (Storyteller)

1. Click **Assign player** (or **Change player**) on that character's row.
2. Type at least three letters of their name, or their exact email.
3. Click **Assign** next to the right person - or, if they haven't registered an account yet, type their email under the pending-email field and click **Save**.

### Confirm a pending player match (Storyteller)

1. When "... now has an account -" appears under **Player**, click **Confirm**.

### Delete a character (Storyteller)

1. Click **Delete** on that character's row.
2. Confirm. This permanently removes the character, its change history, snapshots, sheet style, and connections.

### Give or take XP for one or more characters (Storyteller)

1. Type a whole number in **Apply XP** for each character - a negative number takes XP back.
2. Fill in **Reason** once, below the table.
3. Click that row's **Apply**, or click **Apply All** to send every row you've typed, including ones on other pages.

## Things to know

- As a player, this tab shows only characters linked to your account - not the rest of the chronicle's roster.
- The **Type** filter only offers creature types this chronicle has enabled.
- Deleting a character (Storyteller) can't be undone - it takes the character's change history, snapshots, sheet style, and connections with it.
- An "Also active elsewhere"/"Can't reach a visit" badge next to a name means that character has an open visit to another chronicle - hovering it names every chronicle it's active at. A character hosted here from another chronicle shows no badge on this list - its own sheet carries the "Visiting from ..." notice instead. See [Send Sheet](transfer.md).

## Troubleshooting

- **"No characters found."** Clear or adjust your Type, Status, or search filter.
- **I don't see Assign player, Apply XP, or Delete.** Those are Storyteller-only.
- **Apply or Apply All won't click.** Type a reason, and a whole number from -10,000 to 10,000, other than zero.
- **"That would take XP Earned below zero."** The negative amount is more than this character has earned; apply a smaller correction, or [Request XP](character-editor.md#request-xp) if a player needs it added first.
- **A character I know exists isn't here.** If it isn't linked to your account and you're not a Storyteller, it won't appear - ask a Storyteller to assign it to you.
- **"Failed to load characters."** Refresh the page.

## Related

- [My Chronicle](my-chronicle.md)
- [Character Sheet](character-sheet.md)
- [Character Editor](character-editor.md)
- [Send Sheet](transfer.md)
- [Roles](roles.md)
- [Player Guide](../player-guide.md#1-your-characters)
