<?php

namespace BeyondElysium\Services;

use BeyondElysium\Models\Schema_Block;
use BeyondElysium\Models\World_Object;

defined( 'ABSPATH' ) || exit;

/**
 * The one place Storyteller-only visibility is decided, extracted from three
 * duplicated call sites in `Characters_Controller` and one in
 * `Templates_Controller` (signed-pdf-design.md §3d). ST-only data is filtered
 * in four real operations, not one, and the lesson of `v0.21.28` was that
 * skipping any single one leaks: hiding a block from the resolved *layout*
 * still ships that block's real values inside `sheet_data`, and stripping
 * `sheet_data` still leaves `rp_notes`/`[ST]`-marked `biography`/`notes` text
 * exposed. A server-side PDF generator is a second, direct reader of
 * `Character::find()` - if it skipped this extraction and re-implemented the
 * four operations a fourth time, that fourth copy is exactly how a future
 * change to one copy leaves the other three (or five) stale.
 *
 * `$can_manage` is a caller-supplied boolean rather than this class calling
 * `current_user_can()` itself - keeps every method here pure and testable
 * without mocking WordPress global state, and the caller already knows the
 * answer in every real call site.
 *
 * Deliberately holds no cache of its own. An earlier draft memoized
 * `Schema_Block::storyteller_only_slugs()` in a static property to preserve
 * the "look it up once per page, not once per character" optimization the
 * three original call sites each had - but that optimization was always
 * safely scoped to a local variable inside one method call, never to a
 * class-level static, and a class-level static here reintroduces exactly
 * the bug class this project has already been burned by once (a static memo
 * latching a stale result across PHPUnit test methods that share one PHP
 * process, the same shape as the `v0.21.28` NPC-forms incident). The
 * `$hidden` parameters below let a caller that's about to loop over many
 * characters compute the list once and pass it through instead - the
 * original optimization, kept where it always actually belonged.
 *
 * @see BE_PROCESS/design/signed-pdf-design.md §3d
 */
class St_Visibility {

	/**
	 * Applies all four ST-only redactions to one character row in place:
	 * unsets `rp_notes` entirely, strips `[ST]...[/ST]`-marked text from
	 * `biography`/`notes`, and removes every Storyteller-only block's stored
	 * values from `sheet_data`. A manager is returned untouched.
	 *
	 * @param object        $character
	 * @param object|null   $game      Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool          $can_manage
	 * @param array<string>|null $hidden A caller-computed `storyteller_only_slugs()` result, for a
	 *                                    caller looping over many characters to avoid an N+1; a
	 *                                    single-character caller may omit it for a fresh lookup.
	 */
	public static function filter_character( object $character, ?object $game, bool $can_manage, ?array $hidden = null ): void {
		if ( $can_manage ) {
			return;
		}

		unset( $character->rp_notes );
		$character->biography = St_Filter::strip_html_for_game( (string) ( $character->biography ?? '' ), $game->settings ?? null );
		$character->notes     = St_Filter::strip_html_for_game( (string) ( $character->notes ?? '' ), $game->settings ?? null );
		self::strip_blocks( $character, $hidden ?? Schema_Block::storyteller_only_slugs( (string) ( $game->slug ?? '' ) ) );
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a plot in place - its
	 * `description`, `cliffhanger`, `resolution_details` and
	 * `resolution_impact`, all four rich text - for anyone who isn't a
	 * Storyteller of the chronicle. `st_notes` is not handled here:
	 * `Plots_Controller` removes that field wholesale for a non-manager,
	 * which is stronger than marker-stripping.
	 *
	 * The two resolution fields were missed by 1.0.1 A1 and found by A2's own
	 * coverage guard - they are ordinary rich text on the same form, written
	 * once a plot closes, and were reaching every player unfiltered.
	 *
	 * @param object      $plot       A decoded plot row.
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_plot( object $plot, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		$settings = $game->settings ?? null;
		foreach ( [ 'description', 'cliffhanger', 'resolution_details', 'resolution_impact' ] as $column ) {
			if ( isset( $plot->$column ) && is_string( $plot->$column ) ) {
				$plot->$column = St_Filter::strip_html_for_game( $plot->$column, $settings );
			}
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a plot entry's `content` in
	 * place - every timeline entry, action, response, note and resolution -
	 * for anyone who isn't a Storyteller of the chronicle.
	 *
	 * @param object      $entry      A decoded plot-entry row.
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_entry( object $entry, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		if ( isset( $entry->content ) && is_string( $entry->content ) ) {
			$entry->content = St_Filter::strip_html_for_game( $entry->content, $game->settings ?? null );
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a chronicle's own
	 * `description` in place, for anyone who isn't a Storyteller of it.
	 *
	 * Rich text since 1.0.1 D1 (`wp_kses_post`), so this uses the
	 * dangling-tag-safe HTML strip. The byte-offset one it used while the
	 * field was still `sanitize_textarea_field` would happily cut a marker
	 * that opened inside `<em>` and closed outside it, leaving the tag
	 * unbalanced.
	 *
	 * @param object $game       A decoded game row, also its own settings source.
	 * @param bool   $can_manage
	 */
	public static function filter_game( object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		if ( isset( $game->description ) && is_string( $game->description ) ) {
			$game->description = St_Filter::strip_html_for_game( $game->description, $game->settings ?? null );
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a connection's `notes` in
	 * place - the free text a Storyteller writes when tying an item or a
	 * location to a character - for anyone who isn't a Storyteller.
	 *
	 * Plain text, never rich, so the byte-offset strip is exact.
	 *
	 * @param object      $connection A decoded connection row.
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_connection( object $connection, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		if ( isset( $connection->notes ) && is_string( $connection->notes ) ) {
			$connection->notes = St_Filter::strip_for_game( $connection->notes, $game->settings ?? null );
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from one change record in place - the
	 * submitter's own `notes`, the reviewing Storyteller's `review_notes`, and
	 * the `reason` an approval rule attached - for anyone who isn't a
	 * Storyteller of the chronicle.
	 *
	 * A player reads their own change history, so all three are player-visible
	 * by design. Two of them are written by a Storyteller, and `notes` is too
	 * whenever a Storyteller submits a correction on a player's behalf - so all
	 * three can carry a marker pasted in from Storyteller-only text. Plain
	 * text, never rich, so the byte-offset strip is exact.
	 *
	 * @param object      $change     A change row.
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_change( object $change, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		$settings = $game->settings ?? null;
		foreach ( [ 'notes', 'review_notes', 'reason' ] as $column ) {
			if ( isset( $change->$column ) && is_string( $change->$column ) ) {
				$change->$column = St_Filter::strip_for_game( $change->$column, $settings );
			}
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a submission's `answer_note` in
	 * place - the Storyteller's written answer to a player's question about an
	 * uploaded sheet - for anyone who isn't a Storyteller.
	 *
	 * The note is both returned over REST and mailed to the player
	 * (`Notifications`), so a marker left in it leaks twice over.
	 *
	 * @param object      $submission A submission row.
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_submission( object $submission, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		if ( isset( $submission->answer_note ) && is_string( $submission->answer_note ) ) {
			$submission->answer_note = St_Filter::strip_for_game( $submission->answer_note, $game->settings ?? null );
		}
	}

	/**
	 * Strips `[ST]...[/ST]`-marked text from a world object in place - its
	 * `description`, `limitations`, and every text or string property its
	 * type declares (an item's powers, a location's security, a boon's
	 * terms) - for anyone who isn't a Storyteller of the chronicle
	 * (1.0.0-review F-046, owner ruling on D44). A manager is returned
	 * untouched.
	 *
	 * @param object      $object     A decoded world-object row (`properties` an array).
	 * @param object|null $game       Provides `settings` for `St_Filter`'s per-game markers.
	 * @param bool        $can_manage
	 */
	public static function filter_world_object( object $object, ?object $game, bool $can_manage ): void {
		if ( $can_manage ) {
			return;
		}

		$settings = $game->settings ?? null;
		foreach ( [ 'description', 'limitations' ] as $column ) {
			if ( isset( $object->$column ) && is_string( $object->$column ) ) {
				$object->$column = St_Filter::strip_html_for_game( $object->$column, $settings );
			}
		}

		if ( ! is_array( $object->properties ?? null ) ) {
			return;
		}
		$schema = World_Object::schemas()[ (string) ( $object->object_type ?? '' ) ] ?? [];
		foreach ( $object->properties as $key => $value ) {
			if ( ! is_string( $value ) ) {
				continue;
			}
			// A 'text' property is rich HTML like description/limitations; a plain 'string'
			// one never carries markup, so the cheaper byte-offset strip is exact for it.
			if ( ( $schema[ $key ] ?? null ) === 'text' ) {
				$object->properties[ $key ] = St_Filter::strip_html_for_game( $value, $settings );
			} elseif ( ( $schema[ $key ] ?? null ) === 'string' ) {
				$object->properties[ $key ] = St_Filter::strip_for_game( $value, $settings );
			}
		}
	}

	/**
	 * Removes every Storyteller-only block's stored values from a
	 * character's `sheet_data`. Dropping the section from a resolved
	 * template layout (`filter_layout()`) does not cover this on its own -
	 * the block's own data would still ship inside the character payload.
	 *
	 * @param object        $character
	 * @param array<string> $hidden
	 */
	private static function strip_blocks( object $character, array $hidden ): void {
		if ( ! is_array( $character->sheet_data ?? null ) ) {
			return;
		}

		foreach ( $hidden as $slug ) {
			unset( $character->sheet_data[ $slug ] );
		}
	}

	/**
	 * Removes every Storyteller-only section from a resolved template
	 * layout - the layout-side half of the same visibility rule
	 * `filter_character()` applies to the data side. A manager, or a
	 * layout with no `sections` array, is returned untouched.
	 *
	 * @param array<string,mixed> $layout
	 * @param bool                $can_manage
	 * @param string              $game_slug The chronicle the layout is shown in - a block is
	 *                                        Storyteller-only per chronicle (F-062).
	 * @param array<string>|null  $hidden A caller-computed `storyteller_only_slugs()` result,
	 *                                     for a caller resolving many layouts to avoid an N+1;
	 *                                     omit for a fresh lookup. Also lets this be exercised
	 *                                     as a pure unit test, since `storyteller_only_slugs()`
	 *                                     itself reads `$wpdb`.
	 * @return array<string,mixed>
	 */
	public static function filter_layout( array $layout, bool $can_manage, string $game_slug, ?array $hidden = null ): array {
		if ( $can_manage || ! isset( $layout['sections'] ) || ! is_array( $layout['sections'] ) ) {
			return $layout;
		}

		$hidden = $hidden ?? Schema_Block::storyteller_only_slugs( $game_slug );
		if ( empty( $hidden ) ) {
			return $layout;
		}

		// array_values keeps sections a JSON array rather than a keyed object.
		$layout['sections'] = array_values( array_filter(
			$layout['sections'],
			static fn( $section ) => ! in_array( $section['block_slug'] ?? '', $hidden, true )
		) );

		return $layout;
	}
}
