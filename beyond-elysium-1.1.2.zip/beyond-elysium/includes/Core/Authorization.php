<?php

namespace BeyondElysium\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Central permission-check bridge for Beyond Elysium. Verifies a
 * capability against accessSchema's chronicle-scoped roles first, when
 * enabled for the site and the request names a game, falling back to
 * WordPress's own current_user_can() otherwise. Used by every REST
 * controller's permission callback and by any other code that needs to
 * gate an action.
 */
class Authorization {

	/**
	 * The accessSchema client ID for this plugin.
	 */
	private const CLIENT_ID = 'beyond_elysium';

	/**
	 * Per-request memo of resolved accessSchema role-path checks, keyed by
	 * "{email}|{role_path}" with a true/false value. Cleared at the start
	 * of each PHP request; not a persistent cache.
	 *
	 * @var array<string,bool>
	 */
	private static array $asc_memo = [];

	/**
	 * The plugin's own REST requests currently being served, innermost last.
	 * A stack rather than one slot because a handler can dispatch another
	 * REST request internally (a transfer's verification callback in tests).
	 *
	 * @var \WP_REST_Request[]
	 */
	private static array $request_stack = [];

	/**
	 * Tracks which REST request is being served, so can() answers for the
	 * chronicle in that request's URL. The stack is emptied on rest_api_init
	 * so a request that threw mid-dispatch can never leak into the next.
	 */
	public static function register(): void {
		add_action( 'rest_api_init', [ self::class, 'reset_request_stack' ] );
		add_filter( 'rest_request_before_callbacks', [ self::class, 'push_request' ], 6, 3 );
		add_filter( 'rest_request_after_callbacks', [ self::class, 'pop_request' ], 10, 3 );
	}

	/** Forgets every tracked request. */
	public static function reset_request_stack(): void {
		self::$request_stack = [];
	}

	/**
	 * Records this plugin's REST request as the one being served. Runs on
	 * rest_request_before_callbacks and passes the dispatch through untouched.
	 *
	 * @param mixed            $response
	 * @param array            $handler
	 * @param \WP_REST_Request $request
	 * @return mixed
	 */
	public static function push_request( $response, $handler, $request ) {
		if ( $request instanceof \WP_REST_Request && strpos( (string) $request->get_route(), '/be/v1/' ) === 0 ) {
			self::$request_stack[] = $request;
		}
		return $response;
	}

	/**
	 * Drops the request push_request() recorded, once its callbacks are done.
	 *
	 * @param mixed            $response
	 * @param array            $handler
	 * @param \WP_REST_Request $request
	 * @return mixed
	 */
	public static function pop_request( $response, $handler, $request ) {
		if ( $request instanceof \WP_REST_Request && end( self::$request_stack ) === $request ) {
			array_pop( self::$request_stack );
		}
		return $response;
	}

	/**
	 * Whether the current user holds `$capability` in the chronicle of the
	 * REST request being served - the same resolution a route's permission
	 * callback uses, so a handler's own "is this a Storyteller" decision can
	 * never be wider than the route's (1.0.0-review F-009: a bare
	 * current_user_can() is site-wide, which made a Storyteller of one
	 * chronicle a Storyteller in every chronicle they merely play in).
	 * Outside a REST request - WP-CLI, cron, activation - and on routes with
	 * no chronicle in the URL, it is the plain site-wide capability.
	 */
	public static function can( string $capability ): bool {
		$request = end( self::$request_stack );
		if ( $request instanceof \WP_REST_Request ) {
			return self::check_request( $capability, $request );
		}
		return current_user_can( $capability );
	}

	/**
	 * Reports whether accessSchema-based authorization is enabled for this
	 * site. Reads the be_asc_enabled option, defaulting to false when the
	 * option has never been set.
	 */
	public static function asc_enabled(): bool {
		return (bool) get_option( 'be_asc_enabled', false );
	}

	/**
	 * Chronicle-scoped permission check for a REST request. Resolution
	 * order:
	 *
	 *  1. Not logged in -> deny.
	 *  2. Holds `be_manage_games` -> allow, regardless of route.
	 *  3. No `game_slug` in the request's URL params -> plain
	 *     `current_user_can( $capability )`.
	 *  4. Game resolved, accessSchema enabled, and the game has an
	 *     `asc_role_path` -> for each chronicle role that grants
	 *     `$capability`, check "{asc_role_path}/{ROLE}" against
	 *     accessSchema; any true result allows.
	 *  5. `current_user_can( $capability )` false -> deny.
	 *  6. `$allow_bootstrap` true and the game resolved -> allow without
	 *     requiring a membership row.
	 *  7. Otherwise -> allow only if a `be_game_members` row exists for
	 *     this user and game whose role grants `$capability`; a
	 *     `game_slug` that does not resolve to a real game can never have
	 *     one, so this always denies in that case.
	 *
	 * `game_slug` is read only from `$request->get_url_params()`, never
	 * from `$request['game_slug']` or `get_param()`.
	 *
	 * @param string           $capability WordPress capability being checked.
	 * @param \WP_REST_Request $request
	 * @param bool             $allow_bootstrap Waive the membership-row requirement (not
	 *                                          the capability check) when the game is real
	 *                                          but the user has no membership row yet.
	 * @return bool
	 */
	public static function check_request( string $capability, \WP_REST_Request $request, bool $allow_bootstrap = false ): bool {
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return false;
		}

		if ( current_user_can( 'be_manage_games' ) ) {
			return true;
		}

		$url_params = $request->get_url_params();
		$game_slug  = $url_params['game_slug'] ?? null;

		if ( ! $game_slug ) {
			return current_user_can( $capability );
		}

		$game    = \BeyondElysium\Models\Game::find_by_slug( (string) $game_slug );
		$game_id = $game ? (int) $game->id : 0;

		if ( self::asc_enabled() && $game && ! empty( $game->asc_role_path ) && function_exists( 'owc_asc_check_access' ) ) {
			foreach ( self::roles_granting( $capability ) as $role ) {
				$role_path = self::normalize_role_path( rtrim( (string) $game->asc_role_path, '/' ) . '/' . $role );
				if ( self::check_asc_role_path( $user->user_email, $role_path ) ) {
					return true;
				}
			}
		}

		if ( ! current_user_can( $capability ) ) {
			return false;
		}

		if ( $allow_bootstrap && $game ) {
			return true;
		}

		$member = $game_id ? \BeyondElysium\Models\Game_Member::find( $game_id, $user->ID ) : null;
		if ( ! $member ) {
			return false;
		}

		return in_array( $capability, self::role_grants( $member->role ), true );
	}

	/**
	 * Resolves which of the given capabilities the current user actually holds
	 * for one chronicle - runs check_request() once per capability, reusing its
	 * exact resolution order (accessSchema, the be_manage_games override,
	 * membership rows) rather than duplicating any of it. Backs the per-chronicle
	 * capabilities REST endpoint (page-consolidation-design.md): a client-side
	 * chronicle switcher needs "what can I actually do in THIS chronicle," not
	 * the site-wide, chronicle-blind snapshot `Plugin::enqueue_frontend()`
	 * already localizes on every page regardless of which chronicle it names.
	 *
	 * @param string[]         $capabilities
	 * @param \WP_REST_Request $request      Must carry `game_slug` among its URL params.
	 * @return array<string,bool>
	 */
	public static function capabilities_for_request( array $capabilities, \WP_REST_Request $request ): array {
		$result = [];
		foreach ( $capabilities as $capability ) {
			$result[ $capability ] = self::check_request( $capability, $request );
		}
		return $result;
	}

	/**
	 * Checks one email against one accessSchema role path, memoizing the
	 * result for the rest of the request. Returns false immediately if the
	 * accessSchema integration is not available.
	 */
	private static function check_asc_role_path( string $email, string $role_path ): bool {
		// Guards against direct calls that skip the caller's own function_exists() check.
		if ( ! function_exists( 'owc_asc_check_access' ) ) {
			return false;
		}

		$memo_key = $email . '|' . $role_path;

		if ( ! array_key_exists( $memo_key, self::$asc_memo ) ) {
			$result = owc_asc_check_access( self::CLIENT_ID, $email, $role_path, true );
			self::$asc_memo[ $memo_key ] = ( $result === true );
		}

		return self::$asc_memo[ $memo_key ];
	}

	/**
	 * Normalizes an accessSchema role path to match accessSchema's own
	 * slug format: each `/`-separated segment run through the same
	 * `sanitize_title()` call accessSchema itself uses when a role path is
	 * registered, regardless of how the stored path is cased or
	 * punctuated.
	 *
	 * @param string $role_path
	 * @return string
	 */
	private static function normalize_role_path( string $role_path ): string {
		return implode( '/', array_map( 'sanitize_title', explode( '/', $role_path ) ) );
	}

	/**
	 * Returns the chronicle roles, in game-roles.php's map order, whose
	 * grant list includes the given capability. Used to build the list of
	 * accessSchema role paths to check for one capability.
	 *
	 * @return string[]
	 */
	private static function roles_granting( string $capability ): array {
		$roles = [];
		foreach ( self::game_role_map() as $role => $grants ) {
			if ( in_array( $capability, $grants, true ) ) {
				$roles[] = $role;
			}
		}
		return $roles;
	}

	/**
	 * Whether a WordPress account can use everything a chronicle role grants
	 * through the membership table. A membership only narrows what the site
	 * already allows (check_request() asks the site first), so an HST, AST,
	 * or Narrator on an account without the Editor role holds none of it -
	 * unless accessSchema grants the role instead (1.0.0-review F-104).
	 *
	 * @param \WP_User $user
	 * @param string   $role
	 * @return bool
	 */
	public static function role_usable_by( \WP_User $user, string $role ): bool {
		foreach ( self::role_grants( $role ) as $capability ) {
			if ( ! user_can( $user, $capability ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns the capabilities the given chronicle role grants, from
	 * game-roles.php's map. An unrecognized role returns an empty array,
	 * granting nothing.
	 *
	 * @return string[]
	 */
	private static function role_grants( string $role ): array {
		return self::game_role_map()[ $role ] ?? [];
	}

	/**
	 * Loads and caches game-roles.php's role-to-capabilities map for the
	 * life of the request. Reads the file from disk only on the first
	 * call; every later call returns the same cached array.
	 *
	 * @return array<string,string[]>
	 */
	private static function game_role_map(): array {
		static $map = null;
		if ( $map === null ) {
			$map = require dirname( __DIR__ ) . '/Database/game-roles.php';
		}
		return $map;
	}

	/**
	 * Checks whether the current user has the given capability. When a
	 * role path is supplied and accessSchema is available, checks that
	 * role path first and returns its result if it resolves to a boolean;
	 * otherwise falls back to WordPress's current_user_can().
	 *
	 * @param string      $capability  WordPress capability name (e.g. 'be_manage_games').
	 * @param string|null $role_path   Optional accessSchema role path (e.g. 'Chronicle/KONY/HST').
	 * @return bool
	 */
	public static function check( string $capability, ?string $role_path = null ): bool {
		// A logged-out visitor is a WP_User whose exists() is false, never null.
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return false;
		}

		// Checks the accessSchema role path first, if one is provided.
		if ( $role_path && function_exists( 'owc_asc_check_access' ) ) {
			$result = owc_asc_check_access(
				self::CLIENT_ID,
				$user->user_email,
				$role_path,
				true
			);

			if ( is_bool( $result ) ) {
				return $result;
			}
		}

		// Falls back to the WordPress capability check.
		return current_user_can( $capability );
	}

	/**
	 * Builds a standard 403 WP_Error for a permission-denied REST
	 * response, using the given message or a generic default when none is
	 * supplied.
	 *
	 * @param string $message Optional custom message.
	 * @return \WP_Error
	 */
	public static function denied( string $message = 'You do not have permission to perform this action.' ): \WP_Error {
		return new \WP_Error(
			'rest_forbidden',
			$message,
			[ 'status' => 403 ]
		);
	}
}
