<?php

namespace BeyondElysium\Models;

use BeyondElysium\Database\Manager;
use BeyondElysium\Services\Short_Code;

defined( 'ABSPATH' ) || exit;

/**
 * A per-issuance verification token (GX-7). Exporting a character or signing
 * a PDF mints a fresh, random token here rather than ever publishing the
 * character's own UUID as the public verification key - a UUIDv7 is partly
 * a timestamp and is published as the permanent, cross-plugin character
 * identifier (`INTEROP-UUID.md`), so it can never be rotated or revoked
 * without breaking that separate contract. Revoking one issuance never
 * touches another.
 *
 * Token/short-code generation itself lives in `Services\Short_Code` (1.1.0 §3.13), shared with
 * `Item_Attestation` so the two tables' codes can never collide.
 *
 * @see BE_PROCESS/design/gex-export-transfer-design.md GX-7, §6.2
 */
class Attestation {

	/**
	 * Issues a new attestation for a character: a fresh random token and
	 * short code, a stored copy of exactly what is being attested to (never
	 * re-derived live later - that is what makes `still_matches` meaningful),
	 * and the sha256 of the canonicalized document this issuance covers.
	 *
	 * @param object $character A row from `Character::find()`.
	 * @param string $kind      'gex' | 'pdf' | 'transfer'.
	 * @param string $sheet_hash sha256 of the canonicalized, unredacted export payload this
	 *                           issuance covers - what "has the character changed" compares
	 *                           against (`still_matches()`).
	 * @param string|null $expires_at 'Y-m-d H:i:s', or null for no expiry.
	 * @param string|null $document_hash sha256 of the canonicalized document actually handed
	 *                     over (redacted when the export itself was, unredacted otherwise) -
	 *                     what a receiving chronicle's own copy of the file is compared
	 *                     against (`Sheet_Verification::check()`, F-122). Defaults to
	 *                     `$sheet_hash` when omitted, so an unredacted export (a transfer, or
	 *                     any Storyteller-initiated one) needs no separate value.
	 * @return object The newly created row, decoded (see `find()`).
	 */
	public static function issue( object $character, string $kind, string $sheet_hash, ?string $expires_at = null, ?string $document_hash = null ): object {
		$token      = Short_Code::generate_token();
		$short_code = Short_Code::generate_unique( [ 'character_attestations', 'item_attestations' ] );
		$document_hash = $document_hash ?? $sheet_hash;

		$id = Manager::insert( 'character_attestations', [
			'character_uuid' => $character->uuid,
			'character_id'   => $character->id,
			'game_slug'      => $character->owner_slug,
			'token'          => $token,
			'short_code'     => $short_code,
			'kind'           => $kind,
			'sheet_hash'     => $sheet_hash,
			'attested'       => wp_json_encode( [
				'name'          => $character->name,
				'stack'         => $character->stack_slug,
				'status'        => $character->status,
				'xp_earned'     => (int) $character->xp_earned,
				'xp_unspent'    => (int) $character->xp_unspent,
				'sheet_hash'    => $sheet_hash,
				'document_hash' => $document_hash,
			] ),
			'issued_at'      => current_time( 'mysql', true ),
			'issued_by'      => get_current_user_id(),
			'expires_at'     => $expires_at,
		] );

		$row = self::find( (int) $id );
		if ( $row === null ) {
			throw new \RuntimeException( 'Attestation::issue() failed to insert a row.' );
		}
		return $row;
	}

	/**
	 * Revokes an attestation by its numeric id. Idempotent - revoking an
	 * already-revoked row simply leaves its existing `revoked_at` alone.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function revoke( int $id ): bool {
		global $wpdb;
		$table = Manager::table( 'character_attestations' );
		return (bool) $wpdb->query( $wpdb->prepare(
			"UPDATE {$table} SET revoked_at = %s WHERE id = %d AND revoked_at IS NULL",
			current_time( 'mysql', true ),
			$id
		) );
	}

	/**
	 * Resolves a human-typed short code to its attestation row, recording
	 * the lookup (`check_count`/`last_checked_at`) regardless of outcome -
	 * an issuing Storyteller seeing a code being probed is itself a useful
	 * signal (§6.3). Returns null for a code that simply does not exist;
	 * callers distinguish revoked/expired from "never existed" themselves,
	 * since only the caller knows which of those must 404 versus 200.
	 *
	 * @param string $short_code
	 * @return object|null
	 */
	public static function resolve( string $short_code ): ?object {
		global $wpdb;
		$table = Manager::table( 'character_attestations' );
		$row   = Manager::get_row( "SELECT * FROM {$table} WHERE short_code = %s", strtoupper( trim( $short_code ) ) );
		if ( $row === null ) {
			return null;
		}

		$wpdb->query( $wpdb->prepare(
			"UPDATE {$table} SET check_count = check_count + 1, last_checked_at = %s WHERE id = %d",
			current_time( 'mysql', true ),
			$row->id
		) );

		return self::decode( $row );
	}

	/**
	 * Looks up an attestation by its numeric id, decoded. Used by callers
	 * that already have the id (e.g. right after `issue()`), never by the
	 * public verification endpoint, which only ever receives a short code.
	 *
	 * @param int $id
	 * @return object|null
	 */
	public static function find( int $id ): ?object {
		$table = Manager::table( 'character_attestations' );
		$row   = Manager::get_row( "SELECT * FROM {$table} WHERE id = %d", $id );
		return $row === null ? null : self::decode( $row );
	}

	/**
	 * Marks every attestation past its own `expires_at` as revoked, so a
	 * later `resolve()` treats it the same way as an explicit revocation.
	 * Not yet wired to a cron - no caller needs scheduled sweeping until
	 * GX-8/9's transfer state machine depends on `pending` attestations
	 * actually expiring.
	 *
	 * @return int Number of rows swept.
	 */
	public static function sweep_expired(): int {
		global $wpdb;
		$table = Manager::table( 'character_attestations' );
		return (int) $wpdb->query( $wpdb->prepare(
			"UPDATE {$table} SET revoked_at = %s WHERE revoked_at IS NULL AND expires_at IS NOT NULL AND expires_at < %s",
			current_time( 'mysql', true ),
			current_time( 'mysql', true )
		) );
	}

	/**
	 * @param object $row Raw row from the database.
	 * @return object The same row with `attested` JSON-decoded to an array.
	 */
	private static function decode( object $row ): object {
		$row->attested = json_decode( (string) $row->attested, true ) ?: [];
		return $row;
	}
}
