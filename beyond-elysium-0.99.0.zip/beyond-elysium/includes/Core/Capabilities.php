<?php

namespace BeyondElysium\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Defines Beyond Elysium's custom WordPress capabilities and the roles
 * that receive each one by default. Registers those capabilities onto
 * roles on activation and strips them back off on deactivation. The
 * capability list here is also the source other components (such as the
 * accessSchema role map) derive their own capability lists from.
 */
class Capabilities {

	/**
	 * All custom capabilities and the roles that receive them by default.
	 */
	private const CAPS = [
		'be_manage_games'        => [ 'administrator' ],
		'be_manage_schemas'      => [ 'administrator' ],
		'be_manage_templates'    => [ 'administrator' ],
		'be_manage_characters'   => [ 'administrator', 'editor' ],
		'be_edit_own_characters' => [ 'administrator', 'editor', 'author', 'contributor', 'subscriber' ],
		'be_view_characters'     => [ 'administrator', 'editor', 'author', 'contributor', 'subscriber' ],
		'be_manage_plots'        => [ 'administrator', 'editor' ],
		'be_submit_actions'      => [ 'administrator', 'editor', 'author', 'contributor', 'subscriber' ],
		'be_manage_world_objects'=> [ 'administrator', 'editor' ],
		'be_manage_connections'  => [ 'administrator', 'editor' ],
		'be_run_queries'         => [ 'administrator', 'editor' ],
		// Chronicle-scoped like be_manage_characters, not a site-wide catalog capability.
		'be_import'              => [ 'administrator', 'editor' ],
		// Grants sheet cosmetic overrides: fonts, colors, background, section graphics.
		'be_customize_sheet'     => [ 'administrator', 'editor' ],
		// Chronicle-scoped like be_manage_characters: create/edit/delete approval overrides.
		'be_manage_approval_rules' => [ 'administrator', 'editor' ],
	];

	/**
	 * Returns every custom capability this plugin defines, as a plain list
	 * with the per-role grants stripped off. Used by game-roles.php to
	 * build the chronicle-scoped role grants from the same source list.
	 *
	 * @return string[]
	 */
	public static function all(): array {
		return array_keys( self::CAPS );
	}

	/**
	 * Adds every capability in CAPS to each of its listed roles, via
	 * WP_Role::add_cap(). Skips any role name that does not resolve to a
	 * real WP_Role.
	 */
	public static function register(): void {
		foreach ( self::CAPS as $cap => $role_names ) {
			foreach ( $role_names as $role_name ) {
				$role = get_role( $role_name );
				if ( $role ) {
					$role->add_cap( $cap );
				}
			}
		}
	}

	/**
	 * Removes every capability in CAPS from each of its listed roles, via
	 * WP_Role::remove_cap(). Skips any role name that does not resolve to
	 * a real WP_Role.
	 */
	public static function unregister(): void {
		foreach ( self::CAPS as $cap => $role_names ) {
			foreach ( $role_names as $role_name ) {
				$role = get_role( $role_name );
				if ( $role ) {
					$role->remove_cap( $cap );
				}
			}
		}
	}
}
