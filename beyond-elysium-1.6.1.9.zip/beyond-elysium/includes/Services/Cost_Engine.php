<?php

namespace BeyondElysium\Services;

use BeyondElysium\Models\Schema_Block;

defined( 'ABSPATH' ) || exit;

/**
 * Derives the XP cost of a proposed character change.
 */
class Cost_Engine {

	// Public entry points: DB-touching wrappers.

	/**
	 * Prices one proposed change against a character's current state.
	 *
	 * @param object              $character Character row with decoded (array) `sheet_data` and a
	 *                           `stack_slug`.
	 * @param array<string,mixed> $change    Shape: `change_type`, `change_data` (with `block_slug` plus
	 *                           `trait` / `values` / `fields`), matching `ChangeRequest`.
	 * @return int Signed XP delta - positive costs, negative refunds.
	 */
	public static function cost_for_change( $character, array $change ): int {
		return self::quote_for_change( $character, $change )['xp'];
	}

	/**
	 * The most a Storyteller may price one unit of a custom purchase.
	 */
	public const MAX_CUSTOM_PRICE = 500;

	/**
	 * `cost_for_change()` plus whether the figure is a price.
	 *
	 * @param object              $character  As `cost_for_change()`.
	 * @param array<string,mixed> $change     As `cost_for_change()`.
	 * @param bool                $by_manager Whether the submitter is a Storyteller. Only a Storyteller's own
	 *                           `chosen_cost` on a custom trait is read as its price; a player never
	 *                           prices their own homebrew.
	 * @return array{xp:int,priced:bool,unpriced_reason:?string}
	 */
	public static function quote_for_change( $character, array $change, bool $by_manager = false ): array {
		$change_data = $change['change_data'] ?? [];
		$block_slug  = $change_data['block_slug'] ?? null;
		if ( ! $block_slug ) {
			return self::quoted( 0 );
		}

		// Prefer this character's chronicle-specific fork of the block, if one exists.
		$block = Purchase_Scope::widen( Schema_Block::find_for_game( $block_slug, (string) ( $character->owner_slug ?? '' ) ), (string) ( $character->owner_slug ?? '' ) );
		if ( ! $block ) {
			// A missing block has no cost rule to apply; default to zero.
			return self::quoted( 0 );
		}

		$sheet_data  = is_array( $character->sheet_data ?? null ) ? $character->sheet_data : [];
		$change_type = $change['change_type'] ?? '';

		switch ( $block->section_type ) {
			case 'trait_list':
				return self::quote_trait_list_change( $sheet_data, $block->definition, $block_slug, $change_type, $change_data, $by_manager );

			case 'tiered_power':
				$trait_name = $change_data['trait']['name'] ?? '';
				$in_type    = $trait_name !== '' ? self::is_in_type( $character, $block_slug, $trait_name ) : true;
				return self::quote_tiered_power_change( $sheet_data, $block->definition, $change_type, $change_data, $in_type, $by_manager );

			case 'resource_pool':
				return self::quoted( $by_manager ? 0 : self::price_resource_pool_change( $sheet_data, $block->definition, $block_slug, $change_data ) );

			default:
				// identity_field changes carry no XP cost.
				return self::quoted( 0 );
		}
	}

	/**
	 * Resolves whether a trait is in-type for the character.
	 *
	 * @param object $character
	 */
	public static function is_in_type( $character, string $block_slug, string $trait_name ): bool {
		return ( self::in_type_check( $character, $block_slug ) )( $trait_name );
	}

	/**
	 * Loads what `is_in_type()` needs for one block: the block's section `in_type` tests on the character's creature type.
	 *
	 * @param object|null          $stack  The character's creature stack, when already loaded.
	 * @param array<string,object> $blocks The character's chronicle's blocks by slug, fork-aware, when already loaded.
	 * @param object               $character
	 * @return callable(string):bool
	 */
	public static function in_type_check( $character, string $block_slug, ?object $stack = null, array $blocks = [] ): callable {
		return In_Type::check( $character, $block_slug, $stack, $blocks );
	}

	/**
	 * A trait_list change, quoted.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param array<string,mixed> $change_data
	 * @param object $definition
	 * @return array{xp:int,priced:bool,unpriced_reason:?string}
	 */
	public static function quote_trait_list_change(
		array $sheet_data,
		$definition,
		string $block_slug,
		string $change_type,
		array $change_data,
		bool $by_manager = false
	): array {
		$trait = $change_data['trait'] ?? [];
		$name  = $trait['name'] ?? null;
		if ( $name === null ) {
			return self::quoted( 0 );
		}

		// A list declared unpriced is never bought with XP: every add and raise quotes nothing.
		if ( ! empty( $definition->unpriced ) ) {
			return self::quoted( 0 );
		}

		if ( empty( $trait['custom'] ) && self::find_item( $definition, $name ) !== null ) {
			return self::quoted( $by_manager ? 0 : self::price_trait_list_change( $sheet_data, $definition, $block_slug, $change_type, $change_data ) );
		}

		$sign = ! empty( $definition->negative ) ? -1 : 1;
		$own  = $by_manager ? self::usable_price( $trait['chosen_cost'] ?? null ) : null;

		if ( 'add_trait' === $change_type ) {
			if ( $own === null ) {
				return self::unquoted();
			}
			return self::quoted( $sign * $own * self::row_units( $definition, (int) ( $trait['count'] ?? 1 ) ) );
		}

		if ( 'modify_trait' === $change_type ) {
			if ( self::rows_are_purchases( $definition ) ) {
				return self::quoted( 0 );
			}
			$held      = self::find_held_trait( $sheet_data, $block_slug, $definition, $trait, is_array( $change_data['previous'] ?? null ) ? $change_data['previous'] : null );
			$old_count = $held['count'] ?? 0;
			$new_count = array_key_exists( 'count', $trait ) ? max( 0, (int) $trait['count'] ) : $old_count;
			if ( $new_count <= $old_count ) {
				return self::quoted( 0 );
			}
			$unit = $own ?? ( isset( $held['chosen_cost'] ) ? (int) $held['chosen_cost'] : null );
			if ( $unit === null ) {
				return self::unquoted();
			}
			return self::quoted( $sign * $unit * ( $new_count - $old_count ) );
		}

		return self::quoted( 0 );
	}

	/**
	 * A tiered_power change, quoted.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param array<string,mixed> $change_data
	 * @param object $definition
	 * @return array{xp:int,priced:bool,unpriced_reason:?string}
	 */
	public static function quote_tiered_power_change(
		array $sheet_data,
		$definition,
		string $change_type,
		array $change_data,
		bool $in_type,
		bool $by_manager = false
	): array {
		$trait = $change_data['trait'] ?? [];
		$name  = $trait['name'] ?? null;
		if ( $name === null ) {
			return self::quoted( 0 );
		}

		if ( empty( $trait['custom'] ) && ! self::is_unpriceable_power( $definition, $trait ) ) {
			return self::quoted( $by_manager ? 0 : self::price_tiered_power_change( $sheet_data, $definition, $change_type, $change_data, $in_type ) );
		}

		if ( 'add_trait' === $change_type ) {
			return self::unquoted();
		}
		if ( 'modify_trait' === $change_type && self::raises_a_power( $sheet_data, (string) ( $change_data['block_slug'] ?? '' ), $trait ) ) {
			return self::unquoted();
		}
		return self::quoted( 0 );
	}

	/**
	 * How many units one price covers.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param array<string,mixed> $change_data
	 * @param object $definition
	 * @return array{per:string,units:int}
	 */
	public static function price_units( array $sheet_data, $definition, string $block_slug, string $change_type, array $change_data ): array {
		$trait = $change_data['trait'] ?? [];

		if ( isset( $definition->powers ) && ! isset( $definition->items ) ) {
			$buys = 'add_trait' === $change_type
				|| ( 'modify_trait' === $change_type && self::raises_a_power( $sheet_data, $block_slug, $trait ) );
			return [ 'per' => 'pick', 'units' => $buys ? 1 : 0 ];
		}

		if ( self::rows_are_purchases( $definition ) ) {
			return [ 'per' => 'pick', 'units' => 'add_trait' === $change_type ? 1 : 0 ];
		}

		if ( 'add_trait' === $change_type ) {
			return [ 'per' => 'dot', 'units' => max( 1, (int) ( $trait['count'] ?? 1 ) ) ];
		}
		if ( 'modify_trait' === $change_type && array_key_exists( 'count', $trait ) ) {
			$held      = self::find_held_trait( $sheet_data, $block_slug, $definition, $trait, is_array( $change_data['previous'] ?? null ) ? $change_data['previous'] : null );
			$old_count = $held['count'] ?? 0;
			return [ 'per' => 'dot', 'units' => max( 0, max( 0, (int) $trait['count'] ) - $old_count ) ];
		}
		return [ 'per' => 'dot', 'units' => 0 ];
	}

	/**
	 * What a Storyteller's price makes of a purchase that was waiting for one: the change's own data with the price
	 * stamped onto the trait.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param array<string,mixed> $change_data
	 * @param object $definition
	 * @return array{change_data:array<string,mixed>,xp:int}
	 */
	public static function apply_set_price( array $sheet_data, $definition, string $block_slug, string $change_type, array $change_data, int $set_cost ): array {
		$trait = is_array( $change_data['trait'] ?? null ) ? $change_data['trait'] : [];
		$units = self::price_units( $sheet_data, $definition, $block_slug, $change_type, $change_data );

		if ( 'pick' === $units['per'] ) {
			$carried = 0;
			if ( 'modify_trait' === $change_type && $units['units'] > 0 ) {
				$held    = self::find_held_power( $sheet_data, $block_slug, (string) ( $trait['name'] ?? '' ), isset( $trait['power_name'] ) ? (string) $trait['power_name'] : null );
				$carried = (int) ( $held['chosen_cost'] ?? 0 );
			}
			$trait['chosen_cost'] = $carried + $set_cost;
			$xp                   = ( ! empty( $definition->negative ) ? -1 : 1 ) * ( $units['units'] > 0 ? $set_cost : 0 );
		} else {
			$trait['chosen_cost'] = $set_cost;
			$xp                   = ( ! empty( $definition->negative ) ? -1 : 1 ) * $set_cost * $units['units'];
		}

		$change_data['trait'] = $trait;
		unset( $change_data['cost_pending'] );
		return [ 'change_data' => $change_data, 'xp' => $xp ];
	}

	/** @return array{xp:int,priced:bool,unpriced_reason:?string} */
	private static function quoted( int $xp ): array {
		return [ 'xp' => $xp, 'priced' => true, 'unpriced_reason' => null ];
	}

	/** @return array{xp:int,priced:bool,unpriced_reason:?string} */
	private static function unquoted(): array {
		return [ 'xp' => 0, 'priced' => false, 'unpriced_reason' => 'custom_no_catalog_entry' ];
	}

	/**
	 * A whole number from 0 to `MAX_CUSTOM_PRICE`, or null: what a price is allowed to be.
	 *
	 * @param mixed $value
	 */
	private static function usable_price( $value ): ?int {
		if ( $value === null || ! is_numeric( $value ) || (float) $value !== (float) (int) $value ) {
			return null;
		}
		$price = (int) $value;
		return $price >= 0 && $price <= self::MAX_CUSTOM_PRICE ? $price : null;
	}

	/**
	 * Whether a tiered change names a family, or a pick under one, that the catalog does not carry.
	 *
	 * @param object $definition
	 * @param array<string,mixed> $trait
	 */
	private static function is_unpriceable_power( $definition, array $trait ): bool {
		$power = self::find_power( $definition, (string) ( $trait['name'] ?? '' ) );
		if ( $power === null ) {
			return true;
		}
		$power_name = $trait['power_name'] ?? null;
		return $power_name !== null && self::find_power_level_by_name( $power, (string) $power_name ) === null;
	}

	/**
	 * Whether a tiered `modify_trait` raises the level the character holds.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param array<string,mixed> $trait
	 */
	private static function raises_a_power( array $sheet_data, string $block_slug, array $trait ): bool {
		if ( ! array_key_exists( 'level', $trait ) ) {
			return false;
		}
		$held = self::find_held_power( $sheet_data, $block_slug, (string) ( $trait['name'] ?? '' ), isset( $trait['power_name'] ) ? (string) $trait['power_name'] : null );
		return (int) $trait['level'] > (int) ( $held['level'] ?? 0 );
	}

	/**
	 * Prices an `add_trait`, `remove_trait`, or `modify_trait` change against a trait_list block.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param object $definition
	 * @param array<string,mixed> $change_data
	 */
	public static function price_trait_list_change(
		array $sheet_data,
		$definition,
		string $block_slug,
		string $change_type,
		array $change_data
	): int {
		$trait = $change_data['trait'] ?? [];
		$name  = $trait['name'] ?? null;
		if ( $name === null ) {
			return 0;
		}

		// Homebrew traits have no catalog entry to price against.
		if ( ! empty( $trait['custom'] ) ) {
			return 0;
		}

		$item             = self::find_item( $definition, $name );
		$unit_cost_string = $item ? self::item_cost( $definition, $item ) : null;
		if ( $unit_cost_string === null ) {
			return 0;
		}

		$negative = ! empty( $definition->negative );
		$sign     = $negative ? -1 : 1;

		$held = self::find_held_trait( $sheet_data, $block_slug, $definition, $trait, is_array( $change_data['previous'] ?? null ) ? $change_data['previous'] : null );
		if ( self::rows_are_purchases( $definition ) ) {
			return $sign * self::purchase_change_cost( $unit_cost_string, $change_type, $held, $trait );
		}

		$old_count  = $held['count'] ?? 0;
		$old_chosen = $held['chosen_cost'] ?? null;

		$new_count  = $old_count;
		$new_chosen = $old_chosen;

		if ( 'add_trait' === $change_type ) {
			$old_count  = 0;
			$old_chosen = null;
			$new_count  = max( 1, (int) ( $trait['count'] ?? 1 ) );
			$new_chosen = $trait['chosen_cost'] ?? null;
		} elseif ( 'remove_trait' === $change_type ) {
			$new_count  = 0;
			$new_chosen = null;
		} elseif ( 'modify_trait' === $change_type ) {
			if ( array_key_exists( 'count', $trait ) ) {
				$new_count = max( 0, (int) $trait['count'] );
			}
			if ( array_key_exists( 'chosen_cost', $trait ) ) {
				$new_chosen = $trait['chosen_cost'];
			}
		}

		$old_total        = $old_count > 0 ? self::price_item_cost( $unit_cost_string, $old_chosen ) * $old_count : 0;
		$new_total        = $new_count > 0 ? self::price_item_cost( $unit_cost_string, $new_chosen ) * $new_count : 0;

		return $sign * ( $new_total - $old_total );
	}

	/**
	 * Prices an `add_trait` / `remove_trait` / `modify_trait` change against a tiered_power block.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param object $definition
	 * @param array<string,mixed> $change_data
	 */
	public static function price_tiered_power_change(
		array $sheet_data,
		$definition,
		string $change_type,
		array $change_data,
		bool $in_type
	): int {
		$trait      = $change_data['trait'] ?? [];
		$name       = $trait['name'] ?? null;
		$block_slug = $change_data['block_slug'] ?? '';
		if ( $name === null ) {
			return 0;
		}

		$power = self::find_power( $definition, $name );
		if ( ! $power ) {
			return 0;
		}

		// A `spent_from` block never charges XP - its purchases spend a named resource pool's unspent dots instead.
		if ( isset( $definition->_meta->spent_from ) ) {
			return 0;
		}

		$sequential = ! empty( $definition->sequential );
		$power_name = $trait['power_name'] ?? null;

		if ( $power_name !== null ) {
			$already_held = self::find_held_power( $sheet_data, $block_slug, $name, $power_name ) !== null;
			$cost         = self::pick_cost( $definition, $power, (string) $power_name, $in_type );

			if ( 'remove_trait' === $change_type ) {
				return $already_held ? -$cost : 0;
			}
			if ( 'add_trait' === $change_type ) {
				// A pick that is already held.
				return $already_held ? 0 : $cost;
			}
			// modify_trait reaches here only for a metadata edit (e.g. tradition) on an already-identified pick.
			return 0;
		}

		// Numbered-ladder pricing: one plain holding per family, identified by name alone.
		$held      = self::find_held_power( $sheet_data, $block_slug, $name );
		$old_level = $held['level'] ?? 0;
		$new_level = $old_level;

		if ( 'add_trait' === $change_type ) {
			$old_level = 0;
			$new_level = (int) ( $trait['level'] ?? 1 );
		} elseif ( 'remove_trait' === $change_type ) {
			$new_level = 0;
		} elseif ( 'modify_trait' === $change_type && array_key_exists( 'level', $trait ) ) {
			$new_level = (int) $trait['level'];
		}

		if ( $sequential ) {
			return self::sequential_step_cost( $definition, $power, $old_level, $new_level, $in_type );
		}

		$old_cost = $old_level > 0 ? self::level_cost( $definition, $power, $old_level, $in_type ) : 0;
		$new_cost = $new_level > 0 ? self::level_cost( $definition, $power, $new_level, $in_type ) : 0;
		return $new_cost - $old_cost;
	}

	/**
	 * Prices a `modify_resource` change against a resource_pool block.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @param object $definition
	 * @param array<string,mixed> $change_data
	 */
	public static function price_resource_pool_change( array $sheet_data, $definition, string $block_slug, array $change_data ): int {
		$values = (array) ( $change_data['values'] ?? [] );
		$total  = 0;

		foreach ( $values as $pool_name => $new_value ) {
			$pool_def = self::find_pool( $definition, (string) $pool_name );
			if ( $pool_def === null ) {
				continue;
			}

			$old_value     = $sheet_data[ $block_slug ][ $pool_name ] ?? null;
			$old_permanent = self::pool_permanent_value( $old_value, (int) ( $pool_def->default_start ?? 0 ) );
			$new_permanent = self::pool_permanent_value( $new_value, $old_permanent );

			// A `raised_by` pool is never raised with XP - it converts another pool's temporary points instead.
			if ( isset( $pool_def->raised_by ) && $new_permanent > $old_permanent ) {
				continue;
			}

			$old_cost = self::pool_rating_cost( $pool_def, $old_permanent );
			$new_cost = self::pool_rating_cost( $pool_def, $new_permanent );
			if ( $old_cost === null || $new_cost === null ) {
				continue;
			}
			$total += ! empty( $pool_def->buy_down ) ? max( 0, $new_cost - $old_cost ) : $new_cost - $old_cost;
		}

		return $total;
	}

	/**
	 * Reads a resource pool's permanent rating from its stored value.
	 *
	 * @param mixed $value
	 */
	private static function pool_permanent_value( $value, int $default ): int {
		if ( is_array( $value ) ) {
			return (int) ( $value['permanent'] ?? $default );
		}
		return $value === null ? $default : (int) $value;
	}

	/**
	 * Finds a pool definition by name within a resource_pool block definition.
	 *
	 * @param object $definition
	 * @return object|null
	 */
	private static function find_pool( $definition, string $name ) {
		foreach ( ( $definition->pools ?? [] ) as $pool ) {
			if ( ( $pool->name ?? null ) === $name ) {
				return $pool;
			}
		}
		return null;
	}

	// Held-state pricing: prices what a character currently holds.

	/**
	 * Prices one held `trait_list` entry.
	 *
	 * @param array<string,mixed>  $held       One entry from `sheet_data[block_slug]`: `name`, `count?`, `chosen_cost?`, `custom?`.
	 * @param string               $block_slug The slug this row is held under, for cross-block alias routing; omit to
	 *                                         skip it.
	 * @param array<string,object> $blocks     The character's other blocks, keyed by slug, for `moved_from` resolution - `Point_Audit`'s own already-loaded set.
	 * @param object               $definition
	 * @return array{xp:?int,basis:string,unpriced_reason:?string}
	 */
	public static function price_held_trait_list_item( $definition, array $held, string $block_slug = '', array $blocks = [] ): array {
		$name = $held['name'] ?? null;
		if ( $name === null ) {
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'held_block_not_in_catalog' ];
		}

		if ( ! empty( $held['custom'] ) ) {
			if ( array_key_exists( 'chosen_cost', $held ) && $held['chosen_cost'] !== null ) {
				$count = self::row_units( $definition, (int) ( $held['count'] ?? 1 ) );
				$sign  = ! empty( $definition->negative ) ? -1 : 1;
				return [ 'xp' => $sign * (int) $held['chosen_cost'] * $count, 'basis' => 'chosen_cost', 'unpriced_reason' => null ];
			}
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'custom_no_catalog_entry' ];
		}

		$item = self::find_item( $definition, $name );
		if ( $item === null && $block_slug !== '' && $blocks !== [] ) {
			$moved = Trait_Alias_Resolver::find_moved_item( $blocks, $block_slug, $name );
			if ( $moved !== null && isset( $moved['item']->name ) && is_string( $moved['item']->name ) ) {
				// Re-key the held row to its item's own current name before recursing.
				return self::price_held_trait_list_item(
					is_object( $moved['block']->definition ?? null ) ? $moved['block']->definition : (object) [],
					array_merge( $held, [ 'name' => $moved['item']->name ] )
				);
			}
		}
		if ( $item === null ) {
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'name_not_in_catalog' ];
		}
		$cost_string = self::item_cost( $definition, $item );
		if ( $cost_string === null ) {
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'catalog_item_has_no_cost' ];
		}

		$rule        = self::parse_cost_rule( $cost_string );
		$chosen      = self::rows_are_purchases( $definition ) ? self::purchase_choice( $cost_string, $held ) : ( $held['chosen_cost'] ?? null );
		$unit_cost   = self::price_item_cost( $cost_string, $chosen );
		$count       = self::row_units( $definition, (int) ( $held['count'] ?? 1 ) );
		$sign        = ! empty( $definition->negative ) ? -1 : 1;

		$basis = 'catalog_cost';
		if ( in_array( $rule['type'], [ 'set', 'range' ], true ) ) {
			$basis = $chosen !== null ? 'chosen_cost' : 'rule_floor';
		}

		return [ 'xp' => $sign * $unit_cost * $count, 'basis' => $basis, 'unpriced_reason' => null ];
	}

	/**
	 * Prices one held `tiered_power` entry.
	 *
	 * @param array<string,mixed>  $held       One entry from `sheet_data[block_slug]`: `name`, `level?`, `power_name?`, `custom?`/`keep_custom?`, `chosen_cost?`.
	 * @param bool|null            $in_type    Whether the family is in-type for the character, or null to price it with no rank modifier.
	 * @param string               $block_slug The slug this row is held under, for cross-block alias routing; omit to
	 *                                         skip it.
	 * @param array<string,object> $blocks     The character's other blocks, keyed by slug, for `moved_from` resolution - `Point_Audit`'s own already-loaded set.
	 * @param object               $definition
	 * @return array{xp:?int,basis:string,unpriced_reason:?string}
	 */
	public static function price_held_tiered_power( $definition, array $held, ?bool $in_type, string $block_slug = '', array $blocks = [] ): array {
		$name = $held['name'] ?? null;
		if ( $name === null ) {
			return [ 'xp' => null, 'basis' => 'flat_level', 'unpriced_reason' => 'held_block_not_in_catalog' ];
		}

		$power = self::find_power( $definition, $name );

		if ( ! empty( $held['custom'] ) || ! empty( $held['keep_custom'] ) ) {
			return self::price_held_custom_pick( $definition, $power, $held, $in_type );
		}

		if ( $power === null && $block_slug !== '' && $blocks !== [] ) {
			$moved = Trait_Alias_Resolver::find_moved_power( $blocks, $block_slug, $name );
			if ( $moved !== null && isset( $moved['power']->name ) && is_string( $moved['power']->name ) ) {
				// Re-key the held row to its family's own current name before recursing.
				return self::price_held_tiered_power(
					is_object( $moved['block']->definition ?? null ) ? $moved['block']->definition : (object) [],
					array_merge( $held, [ 'name' => $moved['power']->name ] ),
					$in_type
				);
			}
		}

		if ( $power === null ) {
			return [ 'xp' => null, 'basis' => 'flat_level', 'unpriced_reason' => 'family_not_in_catalog' ];
		}

		$power_name = ( $held['power_name'] ?? '' ) !== '' ? $held['power_name'] : null;

		if ( $power_name !== null ) {
			$level_entry = self::find_power_level_by_name( $power, $power_name );
			if ( $level_entry === null ) {
				return [ 'xp' => null, 'basis' => 'elder_pick', 'unpriced_reason' => 'family_not_in_catalog' ];
			}
			$tier = strtolower( (string) ( $level_entry->tier ?? '' ) );
			if ( $tier === 'innate' && ! isset( $level_entry->cost ) ) {
				return [ 'xp' => 0, 'basis' => 'innate_free', 'unpriced_reason' => null ];
			}
			if ( ! isset( $level_entry->cost ) && ! isset( self::TIER_COSTS[ $tier ] ) ) {
				return [ 'xp' => null, 'basis' => 'elder_pick', 'unpriced_reason' => 'catalog_item_has_no_cost' ];
			}
			$cost  = self::pick_cost( $definition, $power, (string) $power_name, $in_type );
			$basis = isset( $level_entry->cost ) ? 'elder_pick' : 'tier_fallback';
			return [ 'xp' => $cost, 'basis' => $basis, 'unpriced_reason' => null ];
		}

		$level = (int) ( $held['level'] ?? 0 );
		if ( $level <= 0 ) {
			return [ 'xp' => null, 'basis' => 'flat_level', 'unpriced_reason' => 'level_has_no_cost' ];
		}

		if ( self::declares_ladder( $definition ) && ! empty( $definition->sequential ) ) {
			$ceiling = self::untiered_cost_per_level( $definition ) !== null ? count( Power_Levels::ladder( $power ) ) : count( self::ladder_tiers( $definition ) );
			if ( $level > $ceiling ) {
				return self::price_above_ceiling_total( $definition, $power, $ceiling, $level, $in_type );
			}
		}

		if ( ! self::rank_is_valid_for_power( $definition, $power, $level ) ) {
			return [ 'xp' => null, 'basis' => 'flat_level', 'unpriced_reason' => 'level_has_no_cost' ];
		}

		if ( ! empty( $definition->sequential ) ) {
			return [ 'xp' => self::sequential_step_cost( $definition, $power, 0, $level, $in_type ), 'basis' => 'sequential_sum', 'unpriced_reason' => null ];
		}

		return [ 'xp' => self::level_cost( $definition, $power, $level, $in_type ), 'basis' => 'flat_level', 'unpriced_reason' => null ];
	}

	/**
	 * The above-ceiling case: the full declared ladder plus `(level - ceiling)` unnamed picks, each priced at the first
	 * rank above the ladder with that rank's modifier; unpriced when the block declares no rank past its ladder.
	 *
	 * @param object $definition
	 * @param object $power
	 * @return array{xp:?int,basis:string,unpriced_reason:?string}
	 */
	private static function price_above_ceiling_total( $definition, $power, int $ceiling, int $level, ?bool $in_type ): array {
		$pick_rank = self::first_pick_rank( $definition );
		$pick_cost = $pick_rank !== null ? ( self::block_tier_costs( $definition )[ $pick_rank ] ?? null ) : null;
		if ( $pick_cost === null ) {
			return [ 'xp' => null, 'basis' => 'sequential_sum', 'unpriced_reason' => 'level_above_ceiling_no_pick_rank' ];
		}

		$ladder_cost = self::sequential_step_cost( $definition, $power, 0, $ceiling, $in_type );
		$picks       = $level - $ceiling;
		return [ 'xp' => $ladder_cost + $picks * self::apply_modifier( $pick_cost, self::rank_modifier( $definition, $pick_rank, $in_type ) ), 'basis' => 'sequential_sum', 'unpriced_reason' => null ];
	}

	/**
	 * Prices a held custom/keep_custom tiered_power entry: a catalog pick's own cost with its rank's modifier, or the
	 * Storyteller's price.
	 *
	 * @param object $definition
	 * @param object|null $power
	 * @param array<string,mixed> $held
	 * @return array{xp:?int,basis:string,unpriced_reason:?string}
	 */
	private static function price_held_custom_pick( $definition, $power, array $held, ?bool $in_type ): array {
		$power_name = ( $held['power_name'] ?? '' ) !== '' ? $held['power_name'] : null;

		if ( $power !== null && $power_name !== null ) {
			$level_entry = self::find_power_level_by_name( $power, $power_name );
			if ( $level_entry !== null && isset( $level_entry->cost ) ) {
				$tier = strtolower( (string) ( $level_entry->tier ?? '' ) );
				$cost = self::apply_modifier( self::price_item_cost( (string) $level_entry->cost, null ), self::rank_modifier( $definition, $tier !== '' ? $tier : null, $in_type ) );
				return [ 'xp' => $cost, 'basis' => 'elder_pick', 'unpriced_reason' => null ];
			}
		}

		if ( array_key_exists( 'chosen_cost', $held ) && $held['chosen_cost'] !== null ) {
			return [ 'xp' => (int) $held['chosen_cost'], 'basis' => 'chosen_cost', 'unpriced_reason' => null ];
		}

		return [ 'xp' => null, 'basis' => 'elder_pick', 'unpriced_reason' => 'custom_no_catalog_entry' ];
	}

	/**
	 * Prices one held `resource_pool` rating.
	 *
	 * @param mixed $value Raw `sheet_data[block_slug][pool_name]` value - `{permanent,temporary}` or a bare int.
	 * @param object $definition
	 * @return array{xp:?int,basis:string,unpriced_reason:?string}
	 */
	public static function price_held_resource_pool( $definition, string $pool, $value ): array {
		$pool_def = self::find_pool( $definition, $pool );
		if ( $pool_def === null ) {
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'held_block_not_in_catalog' ];
		}

		$cost = self::pool_rating_cost( $pool_def, self::pool_permanent_value( $value, (int) ( $pool_def->default_start ?? 0 ) ) );
		if ( $cost === null ) {
			return [ 'xp' => null, 'basis' => 'catalog_cost', 'unpriced_reason' => 'resource_pool_no_pricing_rule' ];
		}
		return [ 'xp' => $cost, 'basis' => 'catalog_cost', 'unpriced_reason' => null ];
	}

	/**
	 * Finds a tiered_power level entry by its exact numbered `level`.
	 *
	 * @param object $power
	 * @return object|null
	 */
	private static function find_power_level( $power, int $level ) {
		foreach ( Power_Levels::ladder( $power ) as $power_level ) {
			if ( (int) ( $power_level->level ?? 0 ) === $level ) {
				return $power_level;
			}
		}
		return null;
	}

	/**
	 * True when a numbered rank is a real, purchasable position in this power's ladder.
	 *
	 * @param object $definition
	 * @param object $power
	 */
	private static function rank_is_valid_for_power( $definition, $power, int $level ): bool {
		if ( self::untiered_cost_per_level( $definition ) !== null ) {
			return self::find_power_level( $power, $level ) !== null;
		}
		$exact = self::find_power_level( $power, $level );
		if ( $exact !== null ) {
			return isset( $exact->cost );
		}
		$tier = self::tier_for_rank( $definition, $level );
		if ( $tier === null ) {
			return false;
		}
		foreach ( Power_Levels::ladder( $power ) as $power_level ) {
			if ( ( $power_level->tier ?? null ) === $tier ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Maps a numbered rank (1=basic, 2=intermediate,...) to its tier name, using `TIER_COSTS`' own key order (`innate`
	 * excluded - never a numbered rank).
	 *
	 * @param object|array<string,mixed> $definition
	 */
	public static function tier_for_rank( $definition, int $rank ): ?string {
		return self::ladder_tiers( $definition )[ $rank - 1 ] ?? null;
	}

	/**
	 * The block's ladder expanded to one tier name per rung.
	 *
	 * @param object|array<string,mixed> $definition
	 * @return string[]
	 */
	private static function ladder_tiers( $definition ): array {
		$ladder = null;
		if ( is_object( $definition ) && isset( $definition->_meta->ladder ) ) {
			$ladder = (array) $definition->_meta->ladder;
		} elseif ( is_array( $definition ) && isset( $definition['_meta']['ladder'] ) ) {
			$ladder = (array) $definition['_meta']['ladder'];
		}

		if ( $ladder === null ) {
			static $fallback = null;
			if ( $fallback === null ) {
				$fallback = array_values( array_diff( array_keys( self::TIER_COSTS ), [ 'innate' ] ) );
			}
			return $fallback;
		}

		$ranks = self::meta_ranks( $definition );
		$order = $ranks !== null
			? array_values( array_filter( $ranks, static fn( $r ): bool => isset( $ladder[ $r ] ) ) )
			: array_keys( $ladder );

		$tiers = [];
		foreach ( $order as $tier ) {
			for ( $i = 0; $i < (int) $ladder[ $tier ]; $i++ ) {
				$tiers[] = (string) $tier;
			}
		}
		return $tiers;
	}

	/**
	 * Finds a tiered_power level entry by its Elder-and-above `power_name`.
	 *
	 * @param object $power
	 * @return object|null
	 */
	private static function find_power_level_by_name( $power, string $power_name ) {
		return Trait_Alias_Resolver::find_level_by_name( Power_Levels::all( $power ), $power_name );
	}

	/**
	 * The block's declared rank vocabulary (`_meta.ranks`), in book order.
	 *
	 * @param object|array<string,mixed> $definition
	 * @return string[]|null
	 */
	public static function meta_ranks( $definition ): ?array {
		if ( is_object( $definition ) && isset( $definition->_meta->ranks ) ) {
			return array_map( 'strval', (array) $definition->_meta->ranks );
		}
		if ( is_array( $definition ) && isset( $definition['_meta']['ranks'] ) ) {
			return array_map( 'strval', (array) $definition['_meta']['ranks'] );
		}
		return null;
	}

	/**
	 * The first rank above the declared ladder.
	 *
	 * @param object|array<string,mixed> $definition
	 */
	private static function first_pick_rank( $definition ): ?string {
		$ranks = self::meta_ranks( $definition );
		if ( $ranks === null ) {
			return null;
		}
		// Walk `ranks` - book order.
		$ladder = self::meta_ladder( $definition );
		if ( $ladder === [] ) {
			return null;
		}
		$last = -1;
		foreach ( $ranks as $i => $rank ) {
			if ( array_key_exists( $rank, $ladder ) ) {
				$last = (int) $i;
			}
		}
		if ( $last < 0 ) {
			return null;
		}
		return $ranks[ $last + 1 ] ?? null;
	}

	/**
	 * Computes the cost of moving a sequential power between two levels as the sum of every step's cost in between, each
	 * with its own rank's modifier: raising level 2 to 4 costs the level-3 step plus the level-4 step.
	 *
	 * @param object $definition
	 * @param object $power
	 */
	private static function sequential_step_cost( $definition, $power, int $old_level, int $new_level, ?bool $in_type ): int {
		if ( $new_level === $old_level ) {
			return 0;
		}
		$direction = $new_level > $old_level ? 1 : -1;
		$lo        = min( $old_level, $new_level ) + 1;
		$hi        = max( $old_level, $new_level );

		$sum = 0;
		for ( $level = $lo; $level <= $hi; $level++ ) {
			$sum += self::level_cost( $definition, $power, $level, $in_type );
		}
		return $direction * $sum;
	}

	/**
	 * The cost of one level of a tiered power with its rank's modifier applied.
	 *
	 * @param object $definition
	 * @param object $power
	 */
	private static function level_cost( $definition, $power, int $level, ?bool $in_type ): int {
		return self::apply_modifier( self::level_base_cost( $definition, $power, $level ), self::rank_modifier( $definition, self::tier_for_rank( $definition, $level ), $in_type ) );
	}

	/**
	 * Looks up the base cost of one level of a tiered power.
	 *
	 * @param object $definition
	 * @param object $power
	 */
	private static function level_base_cost( $definition, $power, int $level ): int {
		$per_level = self::untiered_cost_per_level( $definition );
		if ( $per_level !== null ) {
			return self::find_power_level( $power, $level ) !== null ? $per_level : 0;
		}

		$tier = self::tier_for_rank( $definition, $level );

		if ( $tier !== null && self::declares_ladder( $definition ) ) {
			return self::block_tier_costs( $definition )[ $tier ] ?? 0;
		}

		$exact = self::find_power_level( $power, $level );
		if ( $exact !== null ) {
			return isset( $exact->cost ) ? self::price_item_cost( (string) $exact->cost, null ) : 0;
		}
		return $tier !== null ? self::block_tier_costs( $definition )[ $tier ] ?? 0 : 0;
	}

	/**
	 * Whether this block declares its own ladder (`_meta.ladder`).
	 *
	 * @param object|array<string,mixed> $definition
	 */
	private static function declares_ladder( $definition ): bool {
		if ( is_object( $definition ) ) {
			return isset( $definition->_meta->ladder );
		}
		return is_array( $definition ) && isset( $definition['_meta']['ladder'] );
	}

	/**
	 * Derives a block's real per-tier cost ladder from its own seeded data.
	 *
	 * @param object $definition
	 * @return array<string,int>
	 */
	private static function block_tier_costs( $definition ): array {
		static $cache = null;
		if ( $cache !== null && $cache[0] === $definition ) {
			return $cache[1];
		}

		$meta_costs = self::meta_costs( $definition );
		if ( $meta_costs !== null ) {
			$costs = array_map( 'intval', $meta_costs );
			$cache = [ $definition, $costs ];
			return $costs;
		}

		$tallies = [];
		foreach ( ( $definition->powers ?? [] ) as $power ) {
			foreach ( Power_Levels::all( $power ) as $power_level ) {
				$tier = $power_level->tier ?? null;
				if ( $tier === null || $tier === 'innate' || ! isset( $power_level->cost ) ) {
					continue;
				}
				$cost = self::price_item_cost( (string) $power_level->cost, null );
				$tallies[ $tier ][ $cost ] = ( $tallies[ $tier ][ $cost ] ?? 0 ) + 1;
			}
		}

		$costs = [];
		foreach ( $tallies as $tier => $by_cost ) {
			arsort( $by_cost );
			$costs[ $tier ] = (int) array_key_first( $by_cost );
		}

		$cache = [ $definition, $costs ];
		return $costs;
	}

	/**
	 * The block's declared ladder (`_meta.ladder`).
	 *
	 * @param object|array<string,mixed> $definition
	 * @return array<string,int>
	 */
	private static function meta_ladder( $definition ): array {
		if ( is_object( $definition ) && isset( $definition->_meta->ladder ) ) {
			return (array) $definition->_meta->ladder;
		}
		if ( is_array( $definition ) && isset( $definition['_meta']['ladder'] ) ) {
			return (array) $definition['_meta']['ladder'];
		}
		return [];
	}

	/**
	 * The block's own declared per-rank costs (`_meta.costs`).
	 *
	 * @param object|array<string,mixed> $definition
	 * @return array<string,int>|null
	 */
	private static function meta_costs( $definition ): ?array {
		if ( is_object( $definition ) && isset( $definition->_meta->costs ) ) {
			return (array) $definition->_meta->costs;
		}
		if ( is_array( $definition ) && isset( $definition['_meta']['costs'] ) ) {
			return (array) $definition['_meta']['costs'];
		}
		return null;
	}

	// Free-text cost parsing.

	/**
	 * Parses a GVM `cost` string into an explicit pricing rule.
	 *
	 * @return array{type: 'fixed'|'set'|'range', values: int[]}
	 */
	public static function parse_cost_rule( string $cost_string ): array {
		$trimmed = trim( $cost_string );

		if ( preg_match( '/^-?\d+$/', $trimmed ) ) {
			return [ 'type' => 'fixed', 'values' => [ (int) $trimmed ] ];
		}

		if ( preg_match( '/^-?\d+(?:\s+or\s+-?\d+)+$/i', $trimmed ) ) {
			$values = array_map( 'intval', preg_split( '/\s+or\s+/i', $trimmed ) ?: [] );
			return [ 'type' => 'set', 'values' => $values ];
		}

		if ( preg_match( '/^(-?\d+)\s*-\s*(-?\d+)$/', $trimmed, $m ) ) {
			return [ 'type' => 'range', 'values' => [ (int) $m[1], (int) $m[2] ] ];
		}

		if ( preg_match( '/-?\d+/', $trimmed, $m ) ) {
			return [ 'type' => 'fixed', 'values' => [ (int) $m[0] ] ];
		}

		return [ 'type' => 'fixed', 'values' => [ 0 ] ];
	}

	/**
	 * Resolves a unit cost from a `cost` string plus the player's chosen value for a variable-cost item.
	 *
	 * @param mixed $chosen
	 */
	public static function price_item_cost( string $cost_string, $chosen ): int {
		$rule = self::parse_cost_rule( $cost_string );

		if ( 'fixed' === $rule['type'] ) {
			return $rule['values'][0];
		}

		if ( 'set' === $rule['type'] ) {
			if ( null !== $chosen && in_array( (int) $chosen, $rule['values'], true ) ) {
				return (int) $chosen;
			}
			return min( $rule['values'] );
		}

		// range
		[ $lo, $hi ] = $rule['values'];
		if ( null !== $chosen && (int) $chosen >= $lo && (int) $chosen <= $hi ) {
			return (int) $chosen;
		}
		return $lo;
	}

	// Rows priced per purchase or per dot.

	/**
	 * Whether each row of a trait_list block is one purchase, priced once whatever its count.
	 *
	 * @param object $definition
	 */
	public static function rows_are_purchases( $definition ): bool {
		return ! empty( $definition->atomic );
	}

	/**
	 * How many units a trait_list row of `$count` is priced as: one on a block whose rows are single purchases, its
	 * count otherwise.
	 *
	 * @param object $definition
	 */
	private static function row_units( $definition, int $count ): int {
		return self::rows_are_purchases( $definition ) ? 1 : max( 1, $count );
	}

	/**
	 * What an `add_trait`, `remove_trait` or `modify_trait` change costs on a block whose rows are single purchases:
	 * the row's price after the change less its price before.
	 *
	 * @param array<string,mixed>|null $held  The held row the change targets, or null when there is none.
	 * @param array<string,mixed>      $trait The change's trait.
	 */
	private static function purchase_change_cost( string $cost_string, string $change_type, ?array $held, array $trait ): int {
		$before = 'add_trait' === $change_type ? null : $held;
		$after  = null;
		if ( 'add_trait' === $change_type ) {
			$after = $trait;
		} elseif ( 'modify_trait' === $change_type && $held !== null ) {
			$after = array_merge( $held, array_intersect_key( $trait, [ 'count' => true, 'chosen_cost' => true ] ) );
		}
		return self::purchase_price( $cost_string, $after ) - self::purchase_price( $cost_string, $before );
	}

	/**
	 * What one row of a block whose rows are single purchases costs, or 0 for no row.
	 *
	 * @param array<string,mixed>|null $row
	 */
	private static function purchase_price( string $cost_string, ?array $row ): int {
		return $row === null ? 0 : self::price_item_cost( $cost_string, self::purchase_choice( $cost_string, $row ) );
	}

	/**
	 * The cost a row of a block whose rows are single purchases chose for a variable-cost item: its `chosen_cost`, or
	 * its `count` when that is one of the item's costs.
	 *
	 * @param array<string,mixed> $row
	 */
	private static function purchase_choice( string $cost_string, array $row ): ?int {
		if ( isset( $row['chosen_cost'] ) ) {
			return (int) $row['chosen_cost'];
		}
		$count = (int) ( $row['count'] ?? 0 );
		$rule  = self::parse_cost_rule( $cost_string );
		if ( 'set' === $rule['type'] ) {
			return in_array( $count, $rule['values'], true ) ? $count : null;
		}
		if ( 'range' === $rule['type'] ) {
			return $count >= $rule['values'][0] && $count <= $rule['values'][1] ? $count : null;
		}
		return null;
	}

	// Lookups.

	/**
	 * Finds a catalog item by name within a trait_list block definition.
	 *
	 * @param object $definition
	 * @return object|null
	 */
	private static function find_item( $definition, string $name ) {
		return Trait_Alias_Resolver::find_item_by_name( (array) ( $definition->items ?? [] ), $name );
	}

	/**
	 * Finds a power by name within a tiered_power block definition.
	 *
	 * @param object $definition
	 * @return object|null
	 */
	private static function find_power( $definition, string $name ) {
		return Trait_Alias_Resolver::find_power_by_name( (array) ( $definition->powers ?? [] ), $name );
	}

	/**
	 * Finds the held row a change actually names, and returns its count and chosen cost, or null when the character holds
	 * no such row.
	 *
	 * @param array<string,mixed>      $sheet_data
	 * @param string                   $block_slug
	 * @param object|null              $definition The block definition the caller already resolved.
	 * @param array<string,mixed>      $trait      The change's own trait payload.
	 * @param array<string,mixed>|null $previous   The change's `previous` snapshot, which names the row a relabel addresses.
	 * @return array{count: int, chosen_cost: int|null}|null
	 */
	private static function find_held_trait( array $sheet_data, string $block_slug, $definition, array $trait, ?array $previous = null ): ?array {
		$identity = Trait_Identity::target_of( $definition, $trait, $previous );
		if ( $identity === null ) {
			return null;
		}

		foreach ( ( $sheet_data[ $block_slug ] ?? [] ) as $item ) {
			if ( is_array( $item ) && Trait_Identity::of_row( $definition, $item ) === $identity ) {
				return [
					'count'       => (int) ( $item['count'] ?? 1 ),
					'chosen_cost' => $item['chosen_cost'] ?? null,
				];
			}
		}
		return null;
	}

	/**
	 * Finds a character's currently held instance of a power within a block.
	 *
	 * @param array<string,mixed> $sheet_data
	 * @return array{level: int, power_name: ?string, chosen_cost: ?int}|null
	 */
	private static function find_held_power( array $sheet_data, string $block_slug, string $name, ?string $power_name = null ): ?array {
		foreach ( ( $sheet_data[ $block_slug ] ?? [] ) as $item ) {
			if ( ( $item['name'] ?? null ) !== $name ) {
				continue;
			}
			$item_power_name = ( $item['power_name'] ?? '' ) !== '' ? $item['power_name'] : null;
			$chosen          = isset( $item['chosen_cost'] ) ? (int) $item['chosen_cost'] : null;
			if ( $power_name !== null ) {
				if ( $item_power_name === $power_name ) {
					return [ 'level' => (int) ( $item['level'] ?? 0 ), 'power_name' => $item_power_name, 'chosen_cost' => $chosen ];
				}
				continue;
			}
			if ( $item_power_name === null ) {
				return [ 'level' => (int) ( $item['level'] ?? 0 ), 'power_name' => null, 'chosen_cost' => $chosen ];
			}
		}
		return null;
	}

	/**
	 * The MET tier ladder costs: Basic 3, Intermediate 6, Advanced 9, Elder 12, Master 15, Ascended 18, Methuselah 21.
	 */
	const TIER_COSTS = [
		'innate'       => 0,
		'basic'        => 3,
		'intermediate' => 6,
		'advanced'     => 9,
		'elder'        => 12,
		'master'       => 15,
		'ascended'     => 18,
		'methuselah'   => 21,
	];

	/**
	 * The base cost of one pick: its own `cost`, or its tier's cost on the MET ladder.
	 *
	 * @param object $power_level
	 */
	private static function pick_base_cost( $power_level ): int {
		if ( isset( $power_level->cost ) ) {
			return self::price_item_cost( (string) $power_level->cost, null );
		}
		return self::TIER_COSTS[ strtolower( (string) ( $power_level->tier ?? '' ) ) ] ?? 0;
	}

	/**
	 * What one pick of a family costs, by power name or alias, with its rank's modifier applied; 0 when the family has
	 * no such pick.
	 *
	 * @param object $definition
	 * @param object $power
	 */
	private static function pick_cost( $definition, $power, string $power_name, ?bool $in_type ): int {
		$power_level = self::find_power_level_by_name( $power, $power_name );
		if ( $power_level === null ) {
			return 0;
		}
		$tier = strtolower( (string) ( $power_level->tier ?? '' ) );
		return self::apply_modifier( self::pick_base_cost( $power_level ), self::rank_modifier( $definition, $tier !== '' ? $tier : null, $in_type ) );
	}

	// Cost expressions.

	/**
	 * A cost with a modifier expression applied: `+N` or `-N` adds, `×N` (also `xN` or `*N`) multiplies, and the result
	 * is never below zero. No expression, or one that is not of those forms, leaves the cost as it is.
	 */
	public static function apply_modifier( int $cost, ?string $expression ): int {
		if ( $expression === null ) {
			return $cost;
		}
		$expression = trim( $expression );
		if ( preg_match( '/^([+-])(\d+)$/', $expression, $m ) ) {
			return max( 0, $m[1] === '+' ? $cost + (int) $m[2] : $cost - (int) $m[2] );
		}
		if ( preg_match( '/^(?:×|x|X|\*)(\d+)$/u', $expression, $m ) ) {
			return max( 0, $cost * (int) $m[1] );
		}
		return $cost;
	}

	/**
	 * Whether a modifier expression is one `apply_modifier()` reads: `+N`, `-N` or `×N`.
	 */
	public static function is_modifier( string $expression ): bool {
		return preg_match( '/^(?:[+-]\d+|(?:×|x|X|\*)\d+)$/u', trim( $expression ) ) === 1;
	}

	/**
	 * The modifier a block declares for one rank on one side: `_meta.in_type` for an in-type purchase, `_meta.out_of_type`
	 * for an out-of-type one; none for no rank, or when the side is not asked for.
	 *
	 * @param object|array<string,mixed> $definition
	 */
	private static function rank_modifier( $definition, ?string $rank, ?bool $in_type ): ?string {
		if ( $rank === null || $in_type === null ) {
			return null;
		}
		$map = self::meta_value( $definition, $in_type ? 'in_type' : 'out_of_type' );
		return is_array( $map ) && isset( $map[ $rank ] ) && is_string( $map[ $rank ] ) ? $map[ $rank ] : null;
	}

	/**
	 * One key of a block's `_meta`, an object read as an array; null when the block has no such key.
	 *
	 * @param object|array<string,mixed> $definition
	 * @return mixed
	 */
	private static function meta_value( $definition, string $key ) {
		$value = null;
		if ( is_object( $definition ) ) {
			$value = $definition->_meta->$key ?? null;
		} elseif ( is_array( $definition ) ) {
			$value = $definition['_meta'][ $key ] ?? null;
		}
		return is_object( $value ) ? (array) $value : $value;
	}

	/**
	 * What one level of an untiered track costs (`_meta.untiered.cost_per_level`), or null for a ranked block or one whose
	 * costs derive from another block.
	 *
	 * @param object|array<string,mixed> $definition
	 */
	private static function untiered_cost_per_level( $definition ): ?int {
		$untiered = self::meta_value( $definition, 'untiered' );
		return is_array( $untiered ) && isset( $untiered['cost_per_level'] ) && is_numeric( $untiered['cost_per_level'] ) ? (int) $untiered['cost_per_level'] : null;
	}

	/**
	 * A trait_list item's cost expression: its own `cost`, or on a block whose `_meta.untiered` derives its costs from
	 * another block, `per_level` for each level the item's prerequisites in that block name; null when neither gives one.
	 *
	 * @param object $definition
	 * @param object $item
	 */
	private static function item_cost( $definition, $item ): ?string {
		if ( isset( $item->cost ) && (string) $item->cost !== '' ) {
			return (string) $item->cost;
		}
		$untiered = self::meta_value( $definition, 'untiered' );
		if ( ! is_array( $untiered ) || ! isset( $untiered['derived_from'], $untiered['per_level'] ) ) {
			return null;
		}
		$levels = 0;
		foreach ( (array) ( $item->prerequisites ?? [] ) as $prerequisite ) {
			$prerequisite = (array) $prerequisite;
			if ( ( $prerequisite['block_slug'] ?? null ) === $untiered['derived_from'] ) {
				$levels += max( 0, (int) ( $prerequisite['min_level'] ?? 0 ) );
			}
		}
		return $levels > 0 ? (string) ( $levels * (int) $untiered['per_level'] ) : null;
	}

	/**
	 * What a pool's rating costs above its free dots: `cost_per_dot` for each dot, or with a `sliding_cost` that
	 * `equals_level`, each dot's own level; null when the pool states neither.
	 *
	 * @param object $pool_def
	 */
	private static function pool_rating_cost( $pool_def, int $rating ): ?int {
		if ( ! empty( $pool_def->buy_down ) ) {
			if ( ! isset( $pool_def->cost_per_dot ) ) {
				return null;
			}
			$start = (int) ( $pool_def->default_start ?? 0 );
			return max( 0, $start - $rating ) * (int) $pool_def->cost_per_dot;
		}

		$free    = (int) ( $pool_def->free_dots ?? 0 );
		$sliding = $pool_def->sliding_cost ?? null;
		$sliding = is_object( $sliding ) ? (array) $sliding : $sliding;
		if ( is_array( $sliding ) && ! empty( $sliding['equals_level'] ) ) {
			return $rating > $free ? intdiv( $rating * ( $rating + 1 ) - $free * ( $free + 1 ), 2 ) : 0;
		}
		if ( ! isset( $pool_def->cost_per_dot ) ) {
			return null;
		}
		return max( 0, $rating - $free ) * (int) $pool_def->cost_per_dot;
	}
}
