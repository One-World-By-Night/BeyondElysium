<?php

namespace BeyondElysium\REST;

use BeyondElysium\Database\Transaction;
use BeyondElysium\Models\Schema_Block;
use BeyondElysium\Services\Rich_Text_Sanitizer;

defined( 'ABSPATH' ) || exit;

/**
 * REST controller for schema blocks, the reusable definitions (trait lists, tiered powers, resource pools, identity
 * fields) that character sheets are built from.
 */
class Schema_Blocks_Controller extends Base_Controller {

	protected $rest_base = 'schema-blocks';

	/**
	 * Registers the REST routes for the schema block collection and for a single block by slug.
	 */
	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => $this->permission( 'be_view_characters' ),
				'args'                => $this->get_collection_params(),
			],
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => $this->permission( 'be_manage_games' ),
				'args'                => $this->get_create_params(),
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<slug>[a-z0-9\-_]+)', [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_item' ],
				'permission_callback' => $this->permission( 'be_view_characters' ),
			],
			[
				'methods'             => 'PUT',
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => $this->permission( 'be_manage_games' ),
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => $this->permission( 'be_manage_games' ),
			],
		] );

		// Game-scoped write routes, with the same callbacks as the routes above.
		register_rest_route( $this->namespace, '/(?P<game_slug>[a-z0-9\-]+)/' . $this->rest_base, [
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => $this->permission( 'be_manage_schemas' ),
				'args'                => $this->get_create_params(),
			],
		] );

		register_rest_route( $this->namespace, '/(?P<game_slug>[a-z0-9\-]+)/' . $this->rest_base . '/(?P<slug>[a-z0-9\-_]+)', [
			[
				'methods'             => 'PUT',
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => $this->permission( 'be_manage_schemas' ),
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => $this->permission( 'be_manage_schemas' ),
			],
		] );
	}

	/**
	 * Returns a paginated list of schema blocks, optionally filtered by section_type, is_system, or a text search, and
	 * ordered by the requested column and direction.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public function get_items( $request ) {
		$pagination = $this->get_pagination( $request );
		$args = [
			'section_type' => $request->get_param( 'section_type' ),
			'is_system'    => $request->get_param( 'is_system' ),
			'search'       => $request->get_param( 'search' ),
			'orderby'      => $request->get_param( 'orderby' ) ?: 'name',
			'order'        => $request->get_param( 'order' ) ?: 'ASC',
			'per_page'     => $pagination['per_page'],
			'offset'       => $pagination['offset'],
		];

		// Optional; when omitted, only global blocks are returned.
		$game_slug = (string) ( $request->get_param( 'game_slug' ) ?? '' );
		$items     = Schema_Block::all_for_game( $args, $game_slug );
		$total     = Schema_Block::count( $args );

		$response = $this->success( $items );
		return $this->paginate( $response, $total, $pagination['per_page'], $pagination['page'] );
	}

	/**
	 * Returns a single schema block by slug, substituting a game's own fork of the block when a game_slug is given.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_item( $request ) {
		// A read resolves the chronicle's own fork, falling back to the global definition; game_slug is a plain query
		// param.
		$game_slug = (string) ( $request->get_param( 'game_slug' ) ?? '' );
		$block     = Schema_Block::find_for_game( $request['slug'], $game_slug );
		if ( ! $block ) {
			return $this->error( 'not_found', __( 'Schema block not found.', 'beyond-elysium' ), 404 );
		}
		return $this->success( $block );
	}

	/**
	 * Creates a chronicle's own schema block from a required slug, name, and section_type.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create_item( $request ) {
		$game_slug = $this->write_scope( $request );
		if ( is_wp_error( $game_slug ) ) {
			return $game_slug;
		}

		$slug         = $request->get_param( 'slug' );
		$name         = $request->get_param( 'name' );
		$section_type = $request->get_param( 'section_type' );

		if ( empty( $slug ) ) {
			return $this->error( 'invalid_param', __( 'Missing required field: slug.', 'beyond-elysium' ), 400 );
		}
		if ( empty( $name ) ) {
			return $this->error( 'invalid_param', __( 'Missing required field: name.', 'beyond-elysium' ), 400 );
		}
		if ( empty( $section_type ) ) {
			return $this->error( 'invalid_param', __( 'Missing required field: section_type.', 'beyond-elysium' ), 400 );
		}
		if ( ! in_array( $section_type, Schema_Block::valid_section_types(), true ) ) {
			return $this->error( 'invalid_section_type', sprintf( __( 'Invalid section_type. Must be one of: %s.', 'beyond-elysium' ), implode( ', ', Schema_Block::valid_section_types() ) ), 400 );
		}

		$definition = $request->get_param( 'definition' );
		if ( $definition !== null ) {
			$validation_error = $this->validate_definition( $section_type, $definition );
			if ( $validation_error ) {
				return $validation_error;
			}
			$definition = $this->sanitize_definition( $section_type, $definition );
		} else {
			$definition = $this->default_definition( $section_type );
		}

		// A slug already in use anywhere.
		if ( Schema_Block::slug_in_use( sanitize_title( $slug ) ) ) {
			return $this->error( 'duplicate_slug', __( 'A schema block with this slug already exists.', 'beyond-elysium' ), 409 );
		}

		$id = Schema_Block::create( [
			'slug'             => $slug,
			'game_slug'        => $game_slug,
			'name'             => $name,
			'section_type'     => $section_type,
			'definition'       => $definition,
			'is_system'        => 0,
			'storyteller_only' => $request->get_param( 'storyteller_only' ) ? 1 : 0,
		] );

		if ( ! $id ) {
			return $this->error( 'create_failed', __( 'Failed to create schema block.', 'beyond-elysium' ), 500 );
		}

		return $this->success( Schema_Block::find( $id ), 201 );
	}

	/**
	 * Updates an existing schema block by slug with any recognized fields present in the request.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_item( $request ) {
		$game_slug = $this->write_scope( $request );
		if ( is_wp_error( $game_slug ) ) {
			return $game_slug;
		}
		$block = Schema_Block::find_for_game( $request['slug'], $game_slug );
		if ( ! $block ) {
			return $this->error( 'not_found', __( 'Schema block not found.', 'beyond-elysium' ), 404 );
		}

		$data = [];
		foreach ( [ 'name', 'section_type', 'definition', 'storyteller_only' ] as $field ) {
			$value = $request->get_param( $field );
			if ( $value !== null ) {
				$data[ $field ] = $value;
			}
		}

		if ( isset( $data['section_type'] ) && ! in_array( $data['section_type'], Schema_Block::valid_section_types(), true ) ) {
			return $this->error( 'invalid_section_type', __( 'Invalid section_type.', 'beyond-elysium' ), 400 );
		}

		if ( isset( $data['definition'] ) ) {
			$section_type     = $data['section_type'] ?? $block->section_type;
			$validation_error = $this->validate_definition( $section_type, $data['definition'] );
			if ( $validation_error ) {
				return $validation_error;
			}
			$data['definition'] = $this->sanitize_definition( $section_type, $data['definition'] );
		}

		if ( ! empty( $data ) ) {
			// A chronicle's first edit makes its copy of the block, and the save lands on that copy or nothing is kept.
			$unit  = Transaction::begin( 'be_schema_block_save' );
			$saved = Schema_Block::find_or_create_fork_for_game( $request['slug'], $game_slug )
				&& Schema_Block::update( $request['slug'], $data, $game_slug );
			if ( ! $saved ) {
				Transaction::rollback( $unit );
				return $this->error( 'save_failed', __( 'Failed to update schema block.', 'beyond-elysium' ), 500 );
			}
			Transaction::commit( $unit );
		}
		return $this->success( Schema_Block::find_for_game( $request['slug'], $game_slug ) );
	}

	/**
	 * Deletes a schema block by slug after confirming it exists and is not a system block.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete_item( $request ) {
		// Reached via the URL's own game_slug this deletes only that chronicle's fork, exact-match.
		$game_slug = $this->write_scope( $request );
		if ( is_wp_error( $game_slug ) ) {
			return $game_slug;
		}
		$block = Schema_Block::find_for_game( $request['slug'], $game_slug );
		if ( ! $block || (string) $block->game_slug !== $game_slug ) {
			return $this->error( 'not_found', __( 'Schema block not found.', 'beyond-elysium' ), 404 );
		}

		if ( ! empty( $block->is_system ) ) {
			return $this->error( 'cannot_delete', __( 'Cannot delete a system schema block.', 'beyond-elysium' ), 403 );
		}

		Schema_Block::delete( $request['slug'], $game_slug );
		return $this->success( null, 204 );
	}

	/**
	 * Returns the chronicle a request addresses: the `game_slug` in the route's own URL, or '' for the book.
	 *
	 * @param \WP_REST_Request $request
	 * @return string|\WP_Error
	 */
	private function scope( \WP_REST_Request $request ) {
		$from_url = (string) ( $request->get_url_params()['game_slug'] ?? '' );
		$param    = $request->get_param( 'game_slug' );
		if ( $from_url === '' && $param !== null && $param !== '' ) {
			return $this->error(
				'use_chronicle_route',
				__( "A chronicle's own schema blocks are changed through that chronicle's route, not the global catalog's.", 'beyond-elysium' ),
				400
			);
		}
		return $from_url;
	}

	/**
	 * Returns the chronicle a write targets. A write without one would change the book, which is read-only.
	 *
	 * @param \WP_REST_Request $request
	 * @return string|\WP_Error
	 */
	private function write_scope( \WP_REST_Request $request ) {
		$scope = $this->scope( $request );
		return $scope === '' ? $this->book_read_only() : $scope;
	}

	/**
	 * Defines the query parameters accepted by the schema block collection endpoint: section_type/is_system/search
	 * filters, orderby/order sort controls, and page/per_page pagination.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public function get_collection_params(): array {
		return [
			'section_type' => [
				'type'              => 'string',
				'enum'              => Schema_Block::valid_section_types(),
				'sanitize_callback' => 'sanitize_text_field',
			],
			'is_system' => [
				'type' => 'integer',
				'enum' => [ 0, 1 ],
			],
			'search' => [
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			],
			'orderby' => [
				'type'    => 'string',
				'default' => 'name',
				'enum'    => [ 'name', 'slug', 'section_type', 'created_at' ],
			],
			'order' => [
				'type'    => 'string',
				'default' => 'ASC',
				'enum'    => [ 'ASC', 'DESC' ],
			],
			'page' => [
				'type'    => 'integer',
				'default' => 1,
				'minimum' => 1,
			],
			'per_page' => [
				'type'    => 'integer',
				'default' => 20,
				'minimum' => 1,
				'maximum' => 100,
			],
		];
	}

	/**
	 * Defines the request parameters accepted when creating a schema block: the required slug, name, and section_type,
	 * plus an optional definition object.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function get_create_params(): array {
		return [
			'slug' => [
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => 'sanitize_title',
			],
			'name' => [
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => 'sanitize_text_field',
			],
			'section_type' => [
				'type'     => 'string',
				'required' => true,
				'enum'     => Schema_Block::valid_section_types(),
			],
			'definition' => [
				'type' => 'object',
			],
		];
	}

	/**
	 * Checks that a definition value contains the array key required for its section_type (items for trait_list, powers
	 * for tiered_power, pools for resource_pool, fields for identity_field).
	 *
	 * @param string $section_type
	 * @param mixed  $definition
	 * @return \WP_Error|null Null on valid, WP_Error on invalid.
	 */
	private function validate_definition( string $section_type, $definition ) {
		// A JSON request body decodes to a plain PHP array; a stdClass is handled too.
		if ( is_string( $definition ) ) {
			$definition = json_decode( $definition, true );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				return $this->error( 'invalid_json', __( 'definition must be a valid JSON object.', 'beyond-elysium' ), 400 );
			}
		} elseif ( is_object( $definition ) ) {
			$definition = json_decode( (string) wp_json_encode( $definition ), true );
		}

		$required_keys = [
			'trait_list'    => 'items',
			'tiered_power'  => 'powers',
			'resource_pool' => 'pools',
			'identity_field' => 'fields',
		];

		$key = $required_keys[ $section_type ] ?? null;
		if ( $key && ( ! is_array( $definition ) || ! isset( $definition[ $key ] ) ) ) {
			return $this->error( 'invalid_param', sprintf( __( 'definition for section_type \'%1$s\' must contain \'%2$s\' array.', 'beyond-elysium' ), $section_type, $key ), 400 );
		}

		return null;
	}

	/**
	 * Normalizes a definition (a JSON string, stdClass, or already-plain array) to a plain array, narrows every
	 * `description` field inside it through Rich_Text_Sanitizer, and narrows the three plain-text faceting fields.
	 *
	 * @param string $section_type
	 * @param mixed  $definition
	 * @return array<string,mixed>
	 */
	private function sanitize_definition( string $section_type, $definition ): array {
		if ( is_string( $definition ) ) {
			$definition = json_decode( $definition, true );
		} elseif ( is_object( $definition ) ) {
			$definition = json_decode( (string) wp_json_encode( $definition ), true );
		}
		return self::sanitize_facets(
			Rich_Text_Sanitizer::sanitize_definition( (array) $definition, $section_type ),
			$section_type
		);
	}

	/**
	 * Narrows a trait_list item's `group`, `subgroup` and `tier`.
	 *
	 * @param array<string,mixed> $definition
	 * @param string              $section_type
	 * @return array<string,mixed>
	 */
	private static function sanitize_facets( array $definition, string $section_type ): array {
		if ( $section_type !== 'trait_list' || ! isset( $definition['items'] ) || ! is_array( $definition['items'] ) ) {
			return $definition;
		}

		foreach ( $definition['items'] as &$item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			foreach ( [ 'group', 'subgroup', 'tier' ] as $field ) {
				if ( ! isset( $item[ $field ] ) ) {
					continue;
				}
				$clean = sanitize_text_field( (string) $item[ $field ] );
				if ( '' === $clean ) {
					unset( $item[ $field ] );
				} else {
					$item[ $field ] = $clean;
				}
			}
		}
		unset( $item );

		return $definition;
	}

	/**
	 * Builds an empty default definition shape for a given section_type, used when creating a schema block without an
	 * explicit definition.
	 *
	 * @param string $section_type
	 * @return array<string,array<int,mixed>>
	 */
	private function default_definition( string $section_type ): array {
		$defaults = [
			'trait_list'     => [ 'items' => [] ],
			'tiered_power'   => [ 'powers' => [] ],
			'resource_pool'  => [ 'pools' => [] ],
			'identity_field' => [ 'fields' => [] ],
		];
		return $defaults[ $section_type ] ?? [];
	}
}
